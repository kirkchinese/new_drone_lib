#!/bin/bash
#gnome-terminal --geometry=80x25+10+10


#* 文件名：[Simlitor_fast_start]

#* 作者：〈版权属于编写者“五月”〉

#* 描述：〈实验性质脚本，用于模拟器初始化〉

#* 修改人：〈五月〉

#* 修改时间：2024-08-01

#* 修改内容：〈ALL〉



# --- for every Terminal-tab
 source ~/.bashrc  # load ~/.bashrc setup
 source $HOME/yy/devel/setup.bash  # ros workspace
 
 
 #启动模拟器

{
	gnome-terminal --tab "run_sim" -- bash -c "cd ~/IntelligentUAVChampionshipSimulator-RMUA2023/ && ./run_simulator.sh;exec bash"

}&
sleep 1

#自动启动vins

{	
	gnome-terminal --tab "vins_run" -- bash -c "echo "启动vins" && cd ~/yy && roslaunch vins fast_drone_250.launch && echo "Done!";exec bash"

}&

sleep 5

{
	gnome-terminal --tab "vins_rviz" -- bash -c "echo "启动vins_rviz" && cd ~/yy && source ~/yy/devel/setup.bash && roslaunch vins rviz.launch && echo "Done!";exec bash"

}&

sleep 1

{
	gnome-terminal --tab "make_and_run" -- bash -c "echo 编译与运行;exec bash"
	cd ~/pos_ctrl
	catkin_make && source devel/setup.bash && roslaunch pos_ctrl pos_ctrl.launch
	echo "Done"

}
