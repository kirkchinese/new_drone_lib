// Auto-generated. Do not edit!

// (in-package yolo_ros.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class target_pose {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.timestamp = null;
      this.curr_pose_x = null;
      this.curr_pose_y = null;
      this.curr_pose_z = null;
      this.curr_pose_yaw = null;
    }
    else {
      if (initObj.hasOwnProperty('timestamp')) {
        this.timestamp = initObj.timestamp
      }
      else {
        this.timestamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('curr_pose_x')) {
        this.curr_pose_x = initObj.curr_pose_x
      }
      else {
        this.curr_pose_x = 0.0;
      }
      if (initObj.hasOwnProperty('curr_pose_y')) {
        this.curr_pose_y = initObj.curr_pose_y
      }
      else {
        this.curr_pose_y = 0.0;
      }
      if (initObj.hasOwnProperty('curr_pose_z')) {
        this.curr_pose_z = initObj.curr_pose_z
      }
      else {
        this.curr_pose_z = 0.0;
      }
      if (initObj.hasOwnProperty('curr_pose_yaw')) {
        this.curr_pose_yaw = initObj.curr_pose_yaw
      }
      else {
        this.curr_pose_yaw = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type target_pose
    // Serialize message field [timestamp]
    bufferOffset = _serializer.time(obj.timestamp, buffer, bufferOffset);
    // Serialize message field [curr_pose_x]
    bufferOffset = _serializer.float64(obj.curr_pose_x, buffer, bufferOffset);
    // Serialize message field [curr_pose_y]
    bufferOffset = _serializer.float64(obj.curr_pose_y, buffer, bufferOffset);
    // Serialize message field [curr_pose_z]
    bufferOffset = _serializer.float64(obj.curr_pose_z, buffer, bufferOffset);
    // Serialize message field [curr_pose_yaw]
    bufferOffset = _serializer.float64(obj.curr_pose_yaw, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type target_pose
    let len;
    let data = new target_pose(null);
    // Deserialize message field [timestamp]
    data.timestamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [curr_pose_x]
    data.curr_pose_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [curr_pose_y]
    data.curr_pose_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [curr_pose_z]
    data.curr_pose_z = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [curr_pose_yaw]
    data.curr_pose_yaw = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 40;
  }

  static datatype() {
    // Returns string type for a message object
    return 'yolo_ros/target_pose';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '490f53dea6cbcfbbe5ceacc7cf40db0c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time timestamp
    float64 curr_pose_x
    float64 curr_pose_y
    float64 curr_pose_z
    float64 curr_pose_yaw
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new target_pose(null);
    if (msg.timestamp !== undefined) {
      resolved.timestamp = msg.timestamp;
    }
    else {
      resolved.timestamp = {secs: 0, nsecs: 0}
    }

    if (msg.curr_pose_x !== undefined) {
      resolved.curr_pose_x = msg.curr_pose_x;
    }
    else {
      resolved.curr_pose_x = 0.0
    }

    if (msg.curr_pose_y !== undefined) {
      resolved.curr_pose_y = msg.curr_pose_y;
    }
    else {
      resolved.curr_pose_y = 0.0
    }

    if (msg.curr_pose_z !== undefined) {
      resolved.curr_pose_z = msg.curr_pose_z;
    }
    else {
      resolved.curr_pose_z = 0.0
    }

    if (msg.curr_pose_yaw !== undefined) {
      resolved.curr_pose_yaw = msg.curr_pose_yaw;
    }
    else {
      resolved.curr_pose_yaw = 0.0
    }

    return resolved;
    }
};

module.exports = target_pose;
