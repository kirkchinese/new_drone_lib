// Auto-generated. Do not edit!

// (in-package yolo_ros.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class yolomsg {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.timestamp = null;
      this.id = null;
      this.Confidence = null;
      this.class_str = null;
      this.xmin = null;
      this.ymin = null;
      this.xmax = null;
      this.ymax = null;
      this.circles_pose_x = null;
      this.circles_pose_y = null;
      this.circles_pose_z = null;
      this.circles_pose_yaw = null;
    }
    else {
      if (initObj.hasOwnProperty('timestamp')) {
        this.timestamp = initObj.timestamp
      }
      else {
        this.timestamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('Confidence')) {
        this.Confidence = initObj.Confidence
      }
      else {
        this.Confidence = 0.0;
      }
      if (initObj.hasOwnProperty('class_str')) {
        this.class_str = initObj.class_str
      }
      else {
        this.class_str = '';
      }
      if (initObj.hasOwnProperty('xmin')) {
        this.xmin = initObj.xmin
      }
      else {
        this.xmin = 0.0;
      }
      if (initObj.hasOwnProperty('ymin')) {
        this.ymin = initObj.ymin
      }
      else {
        this.ymin = 0.0;
      }
      if (initObj.hasOwnProperty('xmax')) {
        this.xmax = initObj.xmax
      }
      else {
        this.xmax = 0.0;
      }
      if (initObj.hasOwnProperty('ymax')) {
        this.ymax = initObj.ymax
      }
      else {
        this.ymax = 0.0;
      }
      if (initObj.hasOwnProperty('circles_pose_x')) {
        this.circles_pose_x = initObj.circles_pose_x
      }
      else {
        this.circles_pose_x = 0.0;
      }
      if (initObj.hasOwnProperty('circles_pose_y')) {
        this.circles_pose_y = initObj.circles_pose_y
      }
      else {
        this.circles_pose_y = 0.0;
      }
      if (initObj.hasOwnProperty('circles_pose_z')) {
        this.circles_pose_z = initObj.circles_pose_z
      }
      else {
        this.circles_pose_z = 0.0;
      }
      if (initObj.hasOwnProperty('circles_pose_yaw')) {
        this.circles_pose_yaw = initObj.circles_pose_yaw
      }
      else {
        this.circles_pose_yaw = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type yolomsg
    // Serialize message field [timestamp]
    bufferOffset = _serializer.time(obj.timestamp, buffer, bufferOffset);
    // Serialize message field [id]
    bufferOffset = _serializer.int64(obj.id, buffer, bufferOffset);
    // Serialize message field [Confidence]
    bufferOffset = _serializer.float64(obj.Confidence, buffer, bufferOffset);
    // Serialize message field [class_str]
    bufferOffset = _serializer.string(obj.class_str, buffer, bufferOffset);
    // Serialize message field [xmin]
    bufferOffset = _serializer.float64(obj.xmin, buffer, bufferOffset);
    // Serialize message field [ymin]
    bufferOffset = _serializer.float64(obj.ymin, buffer, bufferOffset);
    // Serialize message field [xmax]
    bufferOffset = _serializer.float64(obj.xmax, buffer, bufferOffset);
    // Serialize message field [ymax]
    bufferOffset = _serializer.float64(obj.ymax, buffer, bufferOffset);
    // Serialize message field [circles_pose_x]
    bufferOffset = _serializer.float64(obj.circles_pose_x, buffer, bufferOffset);
    // Serialize message field [circles_pose_y]
    bufferOffset = _serializer.float64(obj.circles_pose_y, buffer, bufferOffset);
    // Serialize message field [circles_pose_z]
    bufferOffset = _serializer.float64(obj.circles_pose_z, buffer, bufferOffset);
    // Serialize message field [circles_pose_yaw]
    bufferOffset = _serializer.float64(obj.circles_pose_yaw, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type yolomsg
    let len;
    let data = new yolomsg(null);
    // Deserialize message field [timestamp]
    data.timestamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [id]
    data.id = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [Confidence]
    data.Confidence = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [class_str]
    data.class_str = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [xmin]
    data.xmin = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [ymin]
    data.ymin = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [xmax]
    data.xmax = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [ymax]
    data.ymax = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [circles_pose_x]
    data.circles_pose_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [circles_pose_y]
    data.circles_pose_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [circles_pose_z]
    data.circles_pose_z = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [circles_pose_yaw]
    data.circles_pose_yaw = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.class_str);
    return length + 92;
  }

  static datatype() {
    // Returns string type for a message object
    return 'yolo_ros/yolomsg';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd36891d60db89004a07463a1fe528f69';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time timestamp
    int64 id
    float64 Confidence
    string class_str
    float64 xmin 
    float64 ymin
    float64 xmax
    float64 ymax
    float64 circles_pose_x
    float64 circles_pose_y
    float64 circles_pose_z
    float64 circles_pose_yaw
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new yolomsg(null);
    if (msg.timestamp !== undefined) {
      resolved.timestamp = msg.timestamp;
    }
    else {
      resolved.timestamp = {secs: 0, nsecs: 0}
    }

    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.Confidence !== undefined) {
      resolved.Confidence = msg.Confidence;
    }
    else {
      resolved.Confidence = 0.0
    }

    if (msg.class_str !== undefined) {
      resolved.class_str = msg.class_str;
    }
    else {
      resolved.class_str = ''
    }

    if (msg.xmin !== undefined) {
      resolved.xmin = msg.xmin;
    }
    else {
      resolved.xmin = 0.0
    }

    if (msg.ymin !== undefined) {
      resolved.ymin = msg.ymin;
    }
    else {
      resolved.ymin = 0.0
    }

    if (msg.xmax !== undefined) {
      resolved.xmax = msg.xmax;
    }
    else {
      resolved.xmax = 0.0
    }

    if (msg.ymax !== undefined) {
      resolved.ymax = msg.ymax;
    }
    else {
      resolved.ymax = 0.0
    }

    if (msg.circles_pose_x !== undefined) {
      resolved.circles_pose_x = msg.circles_pose_x;
    }
    else {
      resolved.circles_pose_x = 0.0
    }

    if (msg.circles_pose_y !== undefined) {
      resolved.circles_pose_y = msg.circles_pose_y;
    }
    else {
      resolved.circles_pose_y = 0.0
    }

    if (msg.circles_pose_z !== undefined) {
      resolved.circles_pose_z = msg.circles_pose_z;
    }
    else {
      resolved.circles_pose_z = 0.0
    }

    if (msg.circles_pose_yaw !== undefined) {
      resolved.circles_pose_yaw = msg.circles_pose_yaw;
    }
    else {
      resolved.circles_pose_yaw = 0.0
    }

    return resolved;
    }
};

module.exports = yolomsg;
