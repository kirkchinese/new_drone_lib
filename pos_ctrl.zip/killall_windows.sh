#!/bin/bash
#gnome-terminal --geometry=80x25+10+10


#* 文件名：[Simlitor_fast_start]

#* 作者：〈版权属于编写者“五月”〉

#* 描述：〈实验性质脚本，用于模拟器初始化〉

#* 修改人：〈五月〉

#* 修改时间：2024-08-01

#* 修改内容：〈ALL

killall pos_ctrl RMUA-Linux-Shipping vins_node rviz gnome-terminal-server
gnome-terminal --tab "Hello" -- bash -c "echo "Hello";exec bash"
echo "Done"
