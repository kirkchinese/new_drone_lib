#!/bin/bash
cd /pos_ctrl
source devel/setup.bash
roslaunch pos_ctrl pos_ctrl.launch