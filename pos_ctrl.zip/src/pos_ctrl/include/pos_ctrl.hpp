#ifndef _POS_CTRL_HPP_
#define _POS_CTRL_HPP_

#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include "airsim_ros/VelCmd.h"
#include "airsim_ros/PoseCmd.h"
#include "airsim_ros/Takeoff.h"
#include "airsim_ros/Reset.h"
#include "airsim_ros/Land.h"
#include "airsim_ros/GPSYaw.h"
#include "nav_msgs/Odometry.h"
#include "geometry_msgs/PoseStamped.h"
#include  "sensor_msgs/Imu.h"
#include <time.h>
#include <stdlib.h>
#include "Eigen/Dense"
#include "cv_bridge/cv_bridge.h"
#include "opencv2/opencv.hpp"
#include <ros/callback_queue.h>
#include <boost/thread/thread.hpp>
#include <airsim_ros/SetLocalPosition.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <airsim_ros/CirclePoses.h>
#include <yolo_ros/yolomsg.h>
#include <iostream>
#include <cmath>
#include <string>

#endif


//#define circlesCount 21
#define circlesCount 1000 

class POSCtrl
{
private:
    char kb=0;
    bool exit_flag = 0;
    Eigen::Quaternion<float> q0;
    cv_bridge::CvImageConstPtr cv_front_ptr;
    cv::Mat Lift_front_img;
    cv::Mat Right_front_img;
    bool takeoffflag = 0;
    bool Circle_Pose_flag = true ;
    bool save_image_flag = false;
    int goalpath_index = 0;
    float Pose[4] = {0, 0, 0, 0};
    float RPY[3] = {0,0,0};//pitch roll yaw



    //这个list存储生成的路径点坐标，似乎暂时用不上
    int goalIdx = 0 ;
    float goalpath[circlesCount][4] = {{0,0,0,0}, {0,0,0,0}, {0,0,0,0},{0,0,0,0}, {0,0,0,0}, 
                                    {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, 
                                    {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, 
                                    {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, 
                                    {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0},
                                    {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0},
                                    {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}}; 

    int reference_path_Idx = 0;
    float reference_path[circlesCount][4] = {{0,0,0,0}, {0,0,0,0}, {0,0,0,0},{0,0,0,0}, {0,0,0,0}, 
                                    {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, 
                                    {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, 
                                    {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, 
                                    {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0},
                                    {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0},
                                    {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0}}; 
    //这个list用于存储模拟器给出的近似圆环的坐标
    

    
    int yolo_circles_Idx = 0;
    float yolo_circle_pose[circlesCount][4] = {{-1,-1,-1,-1},{-1,-1,-1,-1},{-1,-1,-1,-1},{-1,-1,-1,-1},
                                            {-1,-1,-1,-1},{-1,-1,-1,-1},{-1,-1,-1,-1},{-1,-1,-1,-1},
                                            {-1,-1,-1,-1},{-1,-1,-1,-1},{-1,-1,-1,-1},{-1,-1,-1,-1},
                                            {-1,-1,-1,-1},{-1,-1,-1,-1},{-1,-1,-1,-1},{-1,-1,-1,-1}}; 
    //这个list用于存储yolo给出的圆环的坐标

    int yolo_list_len_last = 0;
    int yolo_list_len_curr = 0;
    int num_circles = 0;
    bool if_yolo_got_new = false;


    boost::thread kb_thread;
    std::unique_ptr<image_transport::ImageTransport> it;
    ros::Timer go_timer;
    ros::CallbackQueue go_queue;
    ros::CallbackQueue front_img_queue;


    // 调用服务前需要定义特定的调用参数
    airsim_ros::Takeoff takeoff;
    airsim_ros::Land land;
    airsim_ros::Reset reset;

    // 使用publisher发布速度指令需要定义 Velcmd , 并赋予相应的值后，将他publish（）出去
    airsim_ros::VelCmd velcmd;

    // 使用publisher发布速度指令需要定义 Velcmd , 并赋予相应的值后，将他publish（）出去
    airsim_ros::PoseCmd posecmd;

    //无人机信息通过如下命令订阅，当收到消息时自动回调对应的函数
    ros::Subscriber odom_suber;//状态真值，用于赛道一
    // ros::Subscriber imu_suber;//imu数据
    // image_transport::Subscriber bottom_View_suber;
    //image_transport::Subscriber Lift_front_View_suber;
    //image_transport::Subscriber Right_front_View_suber;

    ros::Subscriber CirclePoses ;//圆环真值
    ros::Subscriber Yolo_CirclePoses;

    //通过这两个服务可以调用模拟器中的无人机起飞和降落命令
    ros::ServiceClient takeoff_client;
    ros::ServiceClient land_client;
    ros::ServiceClient setGoalPosition;
    ros::ServiceClient reset_client;

    //通过这两个publisher实现对无人机的速度控制和姿态控制
    ros::Publisher vel_publisher;
    ros::Publisher pose_publisher;

    float get_yaw_from_quat_msg(const geometry_msgs::Quaternion& msg);

    void odom_local_ned_cb(const geometry_msgs::PoseStamped::ConstPtr& msg);
//vins 版本
    //void odom_local_ned_cb(const nav_msgs::OdometryConstPtr &msg);

    void setPosition_cb(const ros::TimerEvent&);

    airsim_ros::SetLocalPosition request11_;

    void Lift_front_view_cb(const sensor_msgs::ImageConstPtr& msg);
    //void Right_front_view_cb(const sensor_msgs::ImageConstPtr& msg);

    template <typename T> int sgn(T val) ;

    void go();

    void go_to(float x, float y, float z, float yaw);

/* 文件名：[pos_ctrl.h]
 * 作者：〈版权属于编写者“五月”〉
 * 描述：〈写圆〉
 * 修改人：〈五月〉
 * 修改时间：2024-07-24
 * 修改内容：〈CirclePoses_get_cb〉
 */
    void CirclePoses_get_cb(const airsim_ros::CirclePoses::ConstPtr& msg);

    void Yolo_CirclePoses_get_cb(const airsim_ros::CirclePoses::ConstPtr& msg);    

    // float get_front_back_point(float x,float y,float z,float yaw, float distance);
    
 /* 文件名：[pos_ctrl.h]
 * 作者：〈版权属于编写者“五月”〉
 * 描述：〈写圆〉
 * 修改人：〈五月〉
 * 修改时间：2024-07-24
 * 修改内容：〈build_parabola〉
 */
//废弃
//   void build_Fake_parabola(float x1, float y1,float z1,float x2, float y2,float z2);
 /* 文件名：[pos_ctrl.h]
 * 作者：〈版权属于编写者“五月”〉
 * 描述：〈写圆〉
 * 修改人：〈五月〉
 * 修改时间：2024-07-24
 * 修改内容：〈build_parabola〉
 */
    float get_distance(float x1, float y1,float z1,float x2,float y2,float z2);





public:



    POSCtrl(ros::NodeHandle *nh);
    ~POSCtrl();

};





