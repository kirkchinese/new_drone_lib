#ifndef _POS_CTRL_CPP_
#define _POS_CTRL_CPP_

#include "pos_ctrl.hpp"

int main(int argc, char** argv)
{
    ros::init(argc, argv, "pos_ctrl"); // 初始化ros 节点，命名为 basic
    ros::NodeHandle n; // 创建node控制句柄
    POSCtrl go(&n);
    return 0;
}

POSCtrl::POSCtrl(ros::NodeHandle *nh)
{  
    //创建图像传输控制句柄
    it = std::make_unique<image_transport::ImageTransport>(*nh); 
    Lift_front_img = cv::Mat(480, 640, CV_8UC3, cv::Scalar(0));
    //Right_front_img = cv::Mat(480, 640, CV_8UC3, cv::Scalar(0));

    takeoff.request.waitOnLastTask = 1;
    land.request.waitOnLastTask = 1;

    // 使用publisher发布速度指令需要定义 Velcmd , 并赋予相应的值后，将他publish（）出去
    velcmd.twist.angular.z = 0;//z方向角速度(yaw, deg)
    velcmd.twist.linear.x = 0.5; //x方向线速度(m/s)
    velcmd.twist.linear.y = 0.0;//y方向线速度(m/s)
    velcmd.twist.linear.z = -0.5;//z方向线速度(m/s)

    // 使用publisher发布速度指令需要定义 Velcmd , 并赋予相应的值后，将他publish（）出去
    posecmd.roll = 0; //x方向姿态(rad)
    posecmd.pitch = 0;//y方向姿态(rad)
    posecmd.yaw = 0;//z方向姿态(rad)
    posecmd.throttle = 0.9;//油门， （0.0-1.0）

    //无人机信息通过如下命令订阅，当收到消息时自动回调对应的函数
    odom_suber = nh->subscribe<geometry_msgs::PoseStamped>("/airsim_node/drone_1/debug/pose_gt", 1, std::bind(&POSCtrl::odom_local_ned_cb, this, std::placeholders::_1));//状态真值，用于赛道一
    // vins 版本 
    //odom_suber = nh->subscribe<nav_msgs::Odometry>("/vins_fusion/imu_propagate", 1, std::bind(&POSCtrl::odom_local_ned_cb, this, std::placeholders::_1));

    CirclePoses = nh->subscribe<airsim_ros::CirclePoses>("/airsim_node/drone_1/circle_poses", 1, std::bind(&POSCtrl::CirclePoses_get_cb, this, std::placeholders::_1));//Circle Poses 真值
    //修改自 五月
    Yolo_CirclePoses = nh->subscribe<airsim_ros::CirclePoses>("/Circle_pose", 1, std::bind(&POSCtrl::Yolo_CirclePoses_get_cb, this, std::placeholders::_1));

    //通过这两个服务可以调用模拟器中的无人机起飞和降落命令
    takeoff_client = nh->serviceClient<airsim_ros::Takeoff>("/airsim_node/drone_1/takeoff");
    land_client = nh->serviceClient<airsim_ros::Takeoff>("/airsim_node/drone_1/land");
    reset_client = nh->serviceClient<airsim_ros::Reset>("/airsim_node/reset");
    setGoalPosition = nh->serviceClient<airsim_ros::SetLocalPosition>("/airsim_node/local_position_goal/override");
    //通过这两个publisher实现对无人机的速度控制和姿态控制
    vel_publisher = nh->advertise<airsim_ros::VelCmd>("airsim_node/drone_1/vel_cmd_body_frame", 1);
    pose_publisher = nh->advertise<airsim_ros::PoseCmd>("airsim_node/drone_1/pose_cmd_body_frame", 1);

    ros::Timer timer = nh->createTimer(ros::Duration(0.5), &POSCtrl::setPosition_cb, this);
    ros::spin();
}

 /* 文件名：[pos_ctrl.cpp]
 * 作者：〈版权属于编写者“五月”〉
 * 描述：〈run〉
 * 修改人：〈五月〉
 * 修改时间：2024-07-21
 * 修改内容：〈添加了卡死跳出(失败)〉
 */


/*void POSCtrl::setPosition_cb(const ros::TimerEvent&)
{   sleep(0.1);
    if(!takeoffflag)
        takeoff_client.call(takeoff);
        takeoffflag = 1;

    for (int i = 0, j = 0; j < num_circles; i += 4, j++) {
        // 设置目标路径基于参考路径
        goalpath[i][0] = reference_path[j][0];
        goalpath[i][1] = reference_path[j][1];
        goalpath[i][2] = reference_path[j][2];
        goalpath[i][3] = reference_path[j][3];

        // 检查是否有有效的 YOLO 圆圈位姿
        if (yolo_circle_pose[j][0] != -1 && yolo_circle_pose[j][1] != -1 && 
            yolo_circle_pose[j][2] != -1 && yolo_circle_pose[j][3] != -1) {
            
            // 计算目标位置
            double yaw = yolo_circle_pose[j][3];
            goalpath[i + 1][0] = yolo_circle_pose[j][0] - 8 * cos(yaw);
            goalpath[i + 1][1] = yolo_circle_pose[j][1] - 8 * sin(yaw);
            goalpath[i + 1][2] = yolo_circle_pose[j][2];
            goalpath[i + 1][3] = yaw;

            goalpath[i + 2][0] = yolo_circle_pose[j][0];
            goalpath[i + 2][1] = yolo_circle_pose[j][1];
            goalpath[i + 2][2] = yolo_circle_pose[j][2];
            goalpath[i + 2][3] = yaw;

            goalpath[i + 3][0] = yolo_circle_pose[j][0] + 8 * cos(yaw);
            goalpath[i + 3][1] = yolo_circle_pose[j][1] + 8 * sin(yaw);
            goalpath[i + 3][2] = yolo_circle_pose[j][2];
            goalpath[i + 3][3] = yaw;
        } else {
            // 如果没有有效的 YOLO 位姿，用参考路径替代
            for (int k = 0; k < 4; k++) {
                if (k % 2 == 0) {  // 偶数索引
                    goalpath[i + k][0] = reference_path[j][0] + 1;
                    goalpath[i + k][2] = reference_path[j][2] + 1;
                    goalpath[i + k][3] = reference_path[j][3];
                } else {  // 基于奇数索引计算
                    goalpath[i + k][1] = reference_path[j][1] - 1;
                    goalpath[i + k][2] = reference_path[j][2] + 1;
                }
            }
            goalpath[i + 3][1] = reference_path[j][1] - 1;
            goalpath[i + 3][2] = reference_path[j][2] - 2;
        }  
    }
    
    
    request11_.request.vehicle_name = "drone_1";
    request11_.request.x = goalpath[goalIdx][0];
    request11_.request.y = goalpath[goalIdx][1]; 
    request11_.request.z = goalpath[goalIdx][2];
    request11_.request.yaw = goalpath[goalIdx][3];
    float d = sqrt(pow(goalpath[goalIdx][0] - Pose[0], 2) + pow(goalpath[goalIdx][1] - Pose[1], 2) + pow(goalpath[goalIdx][2] - Pose[2], 2));
    ROS_INFO("dis to goal: %f", d);
    ROS_INFO("goal : %f %f %f %f", goalpath[goalIdx][0], goalpath[goalIdx][1], goalpath[goalIdx][2], goalpath[goalIdx][3]);
    ROS_INFO("current goalIdx  : %d", goalIdx);
    sleep(0.1);
    if(d < 0.2) { //门限，原值为0.2 现值为0.6 修改者 五月。
        goalIdx += 1;  
        goalIdx %= circlesCount;
        
    }

    setGoalPosition.call(request11_);  //这一句用于发布goal position
    
} */


void POSCtrl::setPosition_cb(const ros::TimerEvent&)
{
    if(!takeoffflag)
        takeoff_client.call(takeoff);
        takeoffflag = 1;
    request11_.request.vehicle_name = "drone_1";
    request11_.request.x = goalpath[goalIdx][0];
    request11_.request.y = goalpath[goalIdx][1]; 
    request11_.request.z = goalpath[goalIdx][2];
    request11_.request.yaw = goalpath[goalIdx][3];
    float d = sqrtf32(powf32((goalpath[goalIdx][0] - Pose[0]),2)+powf32((goalpath[goalIdx][1] - Pose[1]),2)+powf32((goalpath[goalIdx][2] - Pose[2]),2));
    ROS_INFO("dis to goal: %f", d);
    ROS_INFO("goal : %f %f %f %f", goalpath[goalIdx][0], goalpath[goalIdx][1], goalpath[goalIdx][2], goalpath[goalIdx][3]);
    ROS_INFO("current goalIdx  : %d", goalIdx);

    if(d < 1.5) { //门限，原值为0.2 现值为0.6 修改者 五月。
        goalIdx += 1;  
        goalIdx %= circlesCount;
    }
    setGoalPosition.call(request11_);  //这一句用于发布goal position
}


POSCtrl::~POSCtrl()
{
    // cv::destroyAllWindows();
}


/* 文件名：[pos_ctrl.cpp]
 * 作者：〈版权属于编写者“五月”〉
 * 描述：〈Dbug版本的odom〉
 * 修改人：〈五月〉
 * 修改时间：2024-07-28
 * 修改内容：〈odom_local_ned_cb〉
 */

void POSCtrl::odom_local_ned_cb(const geometry_msgs::PoseStamped::ConstPtr& msg)
{
    tf2::Quaternion quat_tf;
    double roll, pitch, yaw;
    tf2::fromMsg(msg->pose.orientation, quat_tf);
    tf2::Matrix3x3(quat_tf).getRPY(roll, pitch, yaw);
    Pose[0] = msg->pose.position.x;
    Pose[1] = msg->pose.position.y;
    Pose[2] = msg->pose.position.z;
    Pose[3] = yaw;
    RPY[0]=roll;
    RPY[1]=pitch;
    RPY[2]=yaw;
}
/* 文件名：[pos_ctrl.cpp]
 * 作者：〈版权属于编写者“五月”〉
 * 描述：〈get_yaw_from_quat_msg〉
 * 修改人：〈五月〉
 * 修改时间：2024-07-28
 * 修改内容：〈get_yaw_from_quat_msg〉
 */

float POSCtrl::get_yaw_from_quat_msg(const geometry_msgs::Quaternion& msg)
{
    Eigen::Quaterniond q(msg.w, msg.x, msg.y, msg.z);
    Eigen::Quaterniond baseq(0.0, 1.0, 0.0, 0.0);
    Eigen::Matrix3d rmtrx = baseq.matrix() * q.matrix();
    Eigen::Vector3d euler = rmtrx.eulerAngles(2, 1, 0);
    
    Eigen::Quaterniond rq(rmtrx);
    
    double siny_cosp = 2 * (rq.w() * rq.z() + rq.x() * rq.y());
    double cosy_cosp = 1 - 2 * (rq.y() * rq.y() + rq.z() * rq.z());
    double yaw = std::atan2(siny_cosp, cosy_cosp);
    
    //std::cout << " q:" << rq.x() <<  " " << rq.y() << " " << rq.z() << " " << rq.w() << " angle:" << euler[0] << " " << euler[1] << " " << euler[2] << " yaw:" << yaw << std::endl;

    return yaw;
}

/* 文件名：[pos_ctrl.cpp]
 * 作者：〈版权属于编写者“五月”〉
 * 描述：〈Vins版本的odom〉
 * 修改人：〈五月〉
 * 修改时间：2024-07-28
 * 修改内容：〈odom_local_ned_cb〉
 */
/*
void POSCtrl::odom_local_ned_cb(const nav_msgs::OdometryConstPtr &msg)
{
    Pose[0] = msg->pose.pose.position.x;
    Pose[1] = -msg->pose.pose.position.y;
    Pose[2] = -msg->pose.pose.position.z;
    Pose[3] = get_yaw_from_quat_msg(msg->pose.pose.orientation);

}
*/



float get_distance(float x1, float y1,float z1,float x2,float y2,float z2)
{
    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2) + pow(z2 - z1, 2));
}

 /* 文件名：[pos_ctrl.cpp]
 * 作者：〈版权属于编写者“五月”〉
 * 描述：〈写圆〉
 * 修改人：〈五月〉
 * 修改时间：2024-07-21
 * 修改内容：〈CirclePoses_get_cb〉
 */

void POSCtrl::CirclePoses_get_cb(const airsim_ros::CirclePoses::ConstPtr& msg)  // 五月改
{    
    num_circles = msg->poses.size();
    if (num_circles > circlesCount) {
        ROS_WARN("Received more circles than expected. Truncating to %d.", circlesCount);
        num_circles = circlesCount;
    }
    if (Circle_Pose_flag == true) {    
        for (int i = 0; i <= num_circles; i++) {
            reference_path[i][0] = msg->poses[i].position.x;
            reference_path[i][1] = msg->poses[i].position.y;

            if (msg->poses[i].position.z > 0) { //这句话用防狗
                reference_path[i][2] = -1.0;
            }else {
                reference_path[i][2] = msg->poses[i].position.z;
            }
            float yaw = msg->poses[i].yaw;
            reference_path[i][3] = yaw * M_PI / 180;
        }  
        Circle_Pose_flag = false;
    }
}

 /* 文件名：[pos_ctrl.cpp]
 * 作者：〈版权属于编写者“五月”〉
 * 描述：〈写圆〉
 * 修改人：〈五月〉
 * 修改时间：2024-08-11
 * 修改内容：〈Yolo_CirclePoses_get_cb〉
 */

void POSCtrl::Yolo_CirclePoses_get_cb(const airsim_ros::CirclePoses::ConstPtr& msg)  // 五月改
{   

    if (msg->poses.empty()) 
    {
    ROS_WARN("Received an empty list of CirclePoses");
    return;
    }
    yolo_list_len_curr = msg->poses.size();
    if (yolo_list_len_curr == yolo_list_len_last) {
        if_yolo_got_new = false;
    }else if (yolo_list_len_curr > yolo_list_len_last) {
        if_yolo_got_new = true;
        yolo_list_len_last = yolo_list_len_curr;
    }
    for (int i = 0; i <= yolo_list_len_curr; i++) {
        yolo_circle_pose[i][0] = msg->poses[i].position.x;
        yolo_circle_pose[i][1] = msg->poses[i].position.y;
        yolo_circle_pose[i][2] = msg->poses[i].position.z;
        float yaw = msg->poses[i].yaw;
        yolo_circle_pose[i][3] = yaw * M_PI / 180;
    }  
    for (int i=1,j=0; i <= circlesCount,j<= 15; i+=3,j++) {
    
        goalpath[i][0] = yolo_circle_pose[j][0];
        goalpath[i][1] = yolo_circle_pose[j][1];
        goalpath[i][2] = yolo_circle_pose[j][2];
        float yaw = yolo_circle_pose[j][3] * M_PI / 180; //将角度转换为弧度
        goalpath[i][3] = yaw;

        goalpath[i-1][0] = yolo_circle_pose[j][0] - 5 * cos(yaw);
        goalpath[i-1][1] = yolo_circle_pose[j][1] - 5 * sin(yaw);
        goalpath[i-1][2] = yolo_circle_pose[j][2];
        goalpath[i-1][3] = yaw;

        goalpath[i+1][0] = yolo_circle_pose[j][0] + 5 * cos(yaw);
        goalpath[i+1][1] = yolo_circle_pose[j][1] + 5 * sin(yaw);
        goalpath[i+1][2] = yolo_circle_pose[j][2];
        goalpath[i+1][3] = yaw;

    }
}

 /* 文件名：[pos_ctrl.cpp]
 * 作者：〈版权属于编写者“五月”〉
 * 描述：〈原版写圆〉
 * 修改人：〈五月〉
 * 修改时间：2024-07-21
 * 修改内容：〈CirclePoses_get_cb〉
 */

/*void POSCtrl::CirclePoses_get_cb(const airsim_ros::CirclePoses::ConstPtr& msg)  // 五月改
{    
    int num_circles = msg->poses.size();
    float distance = 8,distance_b = 8;  //距离，修改者 五月.
    if (num_circles > circlesCount) {
        ROS_WARN("Received more circles than expected. Truncating to %d.", circlesCount);
        num_circles = circlesCount;
    }
    if (Circle_Pose_flag == true) {    
        for (int i = 1,j = 0; i <= num_circles,j<=num_circles; i+=3,j++) {
            goalpath[i][0] = msg->poses[j].position.x;
            goalpath[i][1] = msg->poses[j].position.y;
            goalpath[i][2] = msg->poses[j].position.z;
            float yaw = msg->poses[j].yaw * M_PI / 180;
            goalpath[i][3] = yaw;
        
        if (goalIdx < 21 ){
            goalpath[i+1][0] = goalpath[i][0] + distance_b * cos(yaw);
            goalpath[i+1][1] = goalpath[i][1] + distance_b * sin(yaw);
            goalpath[i+1][2] = goalpath[i][2];
            goalpath[i+1][3] = yaw;

            goalpath[i-1][0] = goalpath[i][0] - distance * cos(yaw);
            goalpath[i-1][1] = goalpath[i][1] - distance * sin(yaw);
            goalpath[i-1][2] = goalpath[i][2];
            goalpath[i-1][3] = yaw;
        }
        else{
            goalpath[i+1][0] = goalpath[i][0] - distance * cos(yaw);
            goalpath[i+1][1] = goalpath[i][1] - distance * sin(yaw);
            goalpath[i+1][2] = goalpath[i][2];
            goalpath[i+1][3] = yaw;

            goalpath[i-1][0] = goalpath[i][0] + distance_b * cos(yaw);
            goalpath[i-1][1] = goalpath[i][1] + distance_b * sin(yaw);
            goalpath[i-1][2] = goalpath[i][2];
            goalpath[i-1][3] = yaw;
            }
        }
        Circle_Pose_flag = false;
    }
}*/

void POSCtrl::Lift_front_view_cb(const sensor_msgs::ImageConstPtr& msg)
{
    cv_front_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::TYPE_8UC3);
    cv::imshow("front_left", cv_front_ptr->image);
    if (save_image_flag == true){
        std::string timestamp = std::to_string(ros::Time::now().toSec());
        std::string savepath = "/home/misaka/auto_drone/images/Lift/front_left_"+timestamp+".png";
        if (cv::imwrite(savepath, cv_front_ptr->image)){
            ROS_INFO("Image saved successfully at: %s", savepath.c_str());
        }else{
            if (errno == EACCES) {
                ROS_ERROR("Permission denied: Unable to save image at: %s", savepath.c_str());
            } else {
                ROS_ERROR("Failed to save image at: %s", savepath.c_str());
            }
        }
    }
}


template <typename T> int POSCtrl::sgn(T val) {
    return (T(0) < val) - (val < T(0));
}

void POSCtrl::go_to(float x, float y, float z, float yaw)
{
    ROS_INFO("get updating pose:%f, %f, %f, %f", Pose[0], Pose[1], Pose[2], Pose[3]);
    // double cout = cpid.caculate(10, Pose[2]);
    velcmd.twist.linear.x =0;
    velcmd.twist.linear.y =0;
    velcmd.twist.angular.z = 0;
    velcmd.twist.linear.z = 0;
    // ROS_INFO("output:%f, %f, %f, %f", 0, 0, velcmd.twist.linear.z, 0);
    vel_publisher.publish(velcmd);
}

void POSCtrl::go()
{
    go_to(0, 0, 50, 0);
}

#endif
