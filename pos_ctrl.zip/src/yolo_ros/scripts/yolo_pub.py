#!/usr/bin/env python3
import sys
sys.path.append('/home/misaka/auto_drone/src/yolo_ros/src/yolov10')
from ultralytics import YOLOv10
import cv2
import rospy
import tf.transformations
from cv_bridge import CvBridge
from geometry_msgs.msg import PoseStamped
from sensor_msgs.msg import Image
from yolo_ros.msg import  yolomsg
from airsim_ros.msg import Circle, CirclePoses
import math
#导入必要的模块与yolov10特定的ultralytics库

odom_list = []
img_write_flag = False
yolo_new_flag = False
cls_name = ['Circle', 'Circle_NO16', 'Circle_Passed', 'Circle_Passing'] #定义检测类别
parameter = [1280, 400, 320, 240] 
# parameter [list] 第一个参数是圆内环的实际大小
# 第二个参数是摄像机的焦距
# 第三个参数是图像宽度/2
# 第四个参数是图像高度/2
# 注意：1200mm是不准的，因为yolo得到的是外径
# 所以需要根据实际情况进行修改

body_frame = [260,-45,0]
#摄像机在机体坐标系中的位置
#注意：这个位置是相对于机体坐标系而言的，单位是毫米
#定义：x，y，z；其中x轴指向前方，y轴指向右侧，z轴指向上方
#注意：这个位置是相对于机体坐标系而言的，单位是毫米

Circle_pose_list = []
#来自yolo的检测数据

Circle_pose_list_sim = []
#来自airsim的近似数据 来自/airsim_node/drone_1/circle_poses 话题


"""
    这是一个失败的状态机类的尝试，目前没有使用
    问题出现在nextpoint上
"""


class State_machine:
    def __init__(self):
        self.curr_state = "none"  #初始化状态为none
        self.curr_Circle = 0
        self.state_counter = 0  #初始化计数器为0

    def update_state(self, new_state):
        next_goal = Circle_pose()
        
        if new_state == "Circle_Passing":
            if self.current_state == "Circle_Passing":
                self.state_counter += 1
            else:
                self.state_counter = 1
            self.current_state = "Circle_Passing"
        
        elif new_state == "Circle_Passed":
            if self.current_state == "Circle_Passing":
                self.state_counter += 1
                if self.state_counter >= 2:  # 连续的 passing 和 passed
                    next_goal = self.next_point("Circle_Passed")
                    self.current_state = "none"  # 重置状态
                    self.state_counter = 0  # 重置计数器
            else:
                self.current_state = "Circle_Passed"
                self.state_counter = 0  # 不连续时重置计数器
        
        elif new_state == "Circle":
            self.current_state = "Circle"
            next_goal = self.next_point("Circle")
            self.state_counter = 0  # 圆环存在时重置计数器
        
        else:
            self.current_state = "none"  # 不识别的状态，重置为none
            next_goal = self.next_point("none")
            self.state_counter = 0  # 不识别状态时重置计数器
        
        return next_goal
    
    def next_point(self, new_state):# 根据当前状态和计数器确定下一个目标点
        pose = Circle_pose()
        if new_state == "Circle_Passed" and yolo_new_flag == True :
            pose.x = Circle_pose_list[-1].x
            pose.y = Circle_pose_list[-1].y
            pose.z = Circle_pose_list[-1].z
            pose.yaw = Circle_pose_list[-1].yaw
            self.curr_Circle = len(Circle_pose_list)-1  #更新当前圆环
            return pose
        elif new_state == "Circle_Passed" and yolo_new_flag == False:
            pose.x = Circle_pose_list_sim[len(Circle_pose_list)].x
            pose.y = Circle_pose_list_sim[len(Circle_pose_list)].y
            pose.z = Circle_pose_list_sim[len(Circle_pose_list)].z
            pose.yaw = Circle_pose_list_sim[len(Circle_pose_list)].yaw
            return pose
        elif new_state == "none" and yolo_new_flag == False:#如果检测不到圆环，则使用仿真数据
            pose.x = Circle_pose_list_sim[self.curr_Circle].x
            pose.y = Circle_pose_list_sim[self.curr_Circle].y
            pose.z = Circle_pose_list_sim[self.curr_Circle].z
            pose.yaw = Circle_pose_list_sim[self.curr_Circle].yaw
            return pose
        elif new_state == "none" and yolo_new_flag == True:
            pose.x = Circle_pose_list[self.curr_Circle].x
            pose.y = Circle_pose_list[self.curr_Circle].y
            pose.z = Circle_pose_list[self.curr_Circle].z
            pose.yaw = Circle_pose_list[self.curr_Circle].yaw
            return pose
        elif new_state == "Circle" and yolo_new_flag == True:
            pose.x = Circle_pose_list[-1].x
            pose.y = Circle_pose_list[-1].y
            pose.z = Circle_pose_list[-1].z
            pose.yaw = Circle_pose_list[-1].yaw
        elif new_state == "Circle" and yolo_new_flag == False:
            pose.x = Circle_pose_list_sim[self.curr_Circle].x
            pose.y = Circle_pose_list_sim[self.curr_Circle].y
            pose.z = Circle_pose_list_sim[self.curr_Circle].z
            pose.yaw = Circle_pose_list_sim[self.curr_Circle].yaw


def Circle_pose_list_Transport():
    circleposes = CirclePoses()
    circleposes.poses = []
    for i in range(len(Circle_pose_list)):
        circleposes.poses.append(Circle_pose_list[i].Transform())
        circleposes.poses[i].index = i
    #circleposes.poses = Circle_pose_list
    return circleposes

class Circle_pose :
    def __init__(self):
        self.x = 0
        self.y = 0
        self.z = 0
        self.yaw = 0
    def Transform(self):
        msg = Circle()
        msg.position.x = self.x
        msg.position.y = self.y
        msg.position.z = self.z
        msg.yaw = self.yaw
        return msg
    def Circle_pose_cb(self, Circle_msg):
        pose = Circle_pose()
        for i in range(len(Circle_msg.poses)):
            pose.x = Circle_msg.poses[i].position.x
            pose.y = Circle_msg.poses[i].position.y
            pose.z = Circle_msg.poses[i].position.z
            pose.yaw = Circle_msg.poses[i].yaw * math.pi/180
            Circle_pose_list_sim.append(pose)

class YOLO_MODULE:
    def __init__(self):   #初始化函数
        self.init_ros()
        self.cv_bridge = CvBridge()
        self.model = YOLOv10("src/yolo_ros/src/yolov10/runs/detect/train8/weights/best.pt")
        #self.model = YOLO("/home/misaka/ROS_catkin_Yolo-V10/src/yolo_ros/src/yolov10/runs/detect/train3/weights/best.pt")
        self.pub = rospy.Publisher("yolomsg", yolomsg, queue_size=10)
        self.Circle_pub = rospy.Publisher("Circle_pose", CirclePoses, queue_size=10)
        self.next_goal_pub = rospy.Publisher("next_goal", Circle, queue_size=10)
        self.time_threshold = 0.005
        self.curr_stamp = rospy.Time.now()
        self.past_stamp = rospy.Time.now()
        
    
    def init_ros(self):
        rospy.init_node("yolo_ros_pub")

    def right_front_view_cb(self, msg):  #定义Image回调函数
        self.curr_stamp = rospy.Time.now()
        if (self.curr_stamp - self.past_stamp).to_sec() <= self.time_threshold: # 如果时间间隔小于阈值，则不处理
            return
        else:
            self.past_stamp = self.curr_stamp
            timestamp = msg.header.stamp
            yolomsgs = yolomsg()        # 创建yolomsg并填入数据
            yolomsgs.timestamp = timestamp
            cv_image = self.cv_bridge.imgmsg_to_cv2(msg, "bgr8")   #将ROS图像消息转换为OpenCV图像   
            results = self.model.predict(cv_image)   #使用 YOLOv10 执行对象检测 
            #发布yolomsg
            # 创建yolomsg并填入数据
            # 并发布yolomsg
            # 若需要将检测结果保存到本地，请将img_write_flag置为True，并在rosrun中加入参数：--img-write
            # 注意：需要保证所需路径存在，否则会报出 IOError 并跳过此次循环
            # 若不希望保存图片，请将 img_write_flag 置为 False

            for r in results:
                circles_id = 0 # 初始化一个变量来存储检测框的id
                for box in r.boxes: 
                    box_list = box.xyxy.tolist()
                    box_list = [x for x in box_list[0]]
                    xmin, ymin, xmax, ymax = box_list
                    yolomsgs.xmin, yolomsgs.ymin, yolomsgs.xmax, yolomsgs.ymax = box_list

                    yolomsgs.Confidence = r.boxes.conf.tolist()[circles_id] #将置信度转换为字符串
                    yolomsgs.class_str = str(cls_name[int(r.boxes.cls.tolist()[circles_id])]) #将类别转换为字符串
                    yolomsgs.id = circles_id
                    
                    if str(cls_name[int(r.boxes.cls.tolist()[circles_id])]) == "Circle" and r.boxes.conf.tolist()[circles_id] >= 0.6:
                        dis_to_front, dis_to_hight, dis_to_width = self.get_distance_to_image(xmin, ymin, xmax, ymax)
                        pose_x, pose_y, pose_z, roll, pitch, pose_yaw = self.Traverse_point(timestamp)
                        if abs(roll) <= 0.0006 and abs(pitch) <= 0.0006 :
                            circles_pose_x = pose_x + ((dis_to_front + body_frame[0]) * math.cos(pose_yaw) - (dis_to_width + body_frame[1]) * math.sin(pose_yaw))/1000
                            circles_pose_y = pose_y + ((dis_to_front + body_frame[0]) * math.sin(pose_yaw) + (dis_to_width + body_frame[1]) * math.cos(pose_yaw))/1000
                            circles_pose_z = pose_z + (dis_to_hight + body_frame[2])/1000          #单位为mm，换成m

                            #circles_pose_z = pose_z + ((dis_to_front + body_frame[0])*math.sin(pitch) + (dis_to_hight + body_frame[2])*math.cos(pitch) + (dis_to_width + body_frame[1])*math.sin(roll))/1000 #考虑了姿态角的影响的版本，但是计算结果不正确，暂时不用，可能是我推错了，也可能是坐标系的问题
        
                            # w = (dis_to_width + body_frame[1])
                            # d = (dis_to_front + body_frame[0])
                            # h = (dis_to_hight + body_frame[2])
                            #考虑了姿态角的影响的版本，但是计算结果不正确，暂时不用，可能是我推错了，也可能是坐标系的问题

                            #circles_pose_x = pose_x + ((dis_to_front + body_frame[0]) * (math.cos(pose_yaw) + math.cos(roll)) - (dis_to_width + body_frame[1]) * math.sin(pose_yaw) + (dis_to_hight + body_frame[2]) * math.sin(roll))/1000
                            #circles_pose_y = pose_y + ((dis_to_width + body_frame[1]) * (math.cos(pitch) + math.cos(pose_yaw)) + (dis_to_hight + body_frame[2]) * math.sin(pitch) + (dis_to_front + body_frame[0]) * math.sin(pose_yaw))/1000
                            #circles_pose_z = pose_z + ((dis_to_hight + body_frame[2]) * (math.cos(pitch) + math.cos(roll)) - (dis_to_width + body_frame[1]) * math.sin(pitch) - (dis_to_front + body_frame[0]) * math.sin(roll))/1000
                        
                            yolomsgs.circles_pose_x = circles_pose_x
                            yolomsgs.circles_pose_y = circles_pose_y
                            yolomsgs.circles_pose_z = circles_pose_z
                            self.update_Circlepose(circles_pose_x, circles_pose_y, circles_pose_z, pose_yaw+math.atan((dis_to_width + body_frame[1])/(dis_to_front + body_frame[0]))) #这里默认看到的圆都是正圆，所以z轴的值就是dis_to_hight，但这是不准的，需要后期修正
                        else:
                            yolomsgs.circles_pose_x = 0             #X-axis
                            yolomsgs.circles_pose_y = 0             #Y-axis
                            yolomsgs.circles_pose_z = 0             #Z-axis 
                        self.pub.publish(yolomsgs)                #发布yolomsg
                        
                        #next_goal_temp = state_machine.update_state(yolomsgs.class_str) # 更新状态机状态
                        #print(next_goal_temp,"我在这里")
                        #next_goal.position.x = next_goal_temp.x
                        #next_goal.position.y = next_goal_temp.y
                        #next_goal.position.z = next_goal_temp.z
                        #next_goal.yaw = next_goal_temp.yaw
                        #self.next_goal_pub.publish(next_goal) # 发布下一个目标点

                        circles_id+=1
                        if img_write_flag:  # 如果需要保存图片
                            savepath = f"/home/misaka/pos_ctrl/images/Right/front_Right_{timestamp}.png"
                            cv_image_with_box = cv2.rectangle(cv_image, (xmin, ymin), (xmax, ymax), (0, 255, 0), 2)
                            if cv2.imwrite(savepath, cv_image_with_box):
                                rospy.loginfo(f"Image saved successfully at: {savepath}")
                            else:
                                rospy.logerr(f"Failed to sav    e image at: {savepath}")
                        else:
                            rospy.loginfo("Image saving is disabled.")
                            #cv_image = cv2.rectangle(cv_image, (yolomsgs.xmin, yolomsgs.ymin), (yolomsgs.xmax, yolomsgs.ymax), (0, 255, 0), 2)
                            #cv2.imshow("Image", cv_image)
            #(self.curr_stamp - rospy.Time.now()).to_sec()
            rospy.loginfo("本次用时： %s 秒", (rospy.Time.now() - self.curr_stamp).to_sec())
            self.Circle_pub.publish(Circle_pose_list_Transport())
            #print("当前的Circle_pose_list为：", Circle_pose_list[0].x)             #debug

    def get_distance_to_image(self, xmin, ymin, xmax, ymax):
        distance_object_to_image = (parameter[1] * parameter[0])/(math.sqrt((xmax - xmin) * (ymax - ymin)))
        y_to_hight = -(distance_object_to_image * (((ymax + ymin) / 2) - parameter[3])) / parameter[1]
        #这里有负号是因为图像坐标系和相机坐标系y轴方向相反
        x_to_width = (distance_object_to_image * (((xmax + xmin) / 2) - parameter[2])) / parameter[1]
        return (distance_object_to_image, y_to_hight, x_to_width)
    
    def Pose_Stamped_cb(self, odom_msg):
        #self.curr_stamp = rospy.Time.now()
        #if (self.curr_stamp - self.past_stamp).to_sec() <= self.time_threshold: # 如果时间间隔小于阈值，则不处理
            #return
        #else:
            #odom_list.append(odom_msg)  #将时间戳和位置添加到odom_list中
            #if len(odom_list) >= 1000000:
                #odom_list.pop(0)  #如果odom_list长度超过100，则删除最早的数据

        odom_list.append(odom_msg)  #将时间戳和位置添加到odom_list中
        if len(odom_list) >= 1000000:
            odom_list.pop(0)  #如果odom_list长度超过100000，则删除最早的数据

    def Traverse_point(self, timestamp):# 遍历odom_list，找到与传入的时间戳最接近的数据
        # 若odom_list为空，返回None             #因为更新足够快，所以其实不需要这个判断...
        #if len(odom_list) == 0:              #为了提升速度，把这个删了，如果需要的话可以加回来
        #    return None
        # 找到与传入的时间戳最接近的数据
        nearest_odom_msg = min(odom_list, key=lambda x: abs(x.header.stamp - timestamp))
        nearest_pose_x = nearest_odom_msg.pose.position.x
        nearest_pose_y = nearest_odom_msg.pose.position.y
        nearest_pose_z = nearest_odom_msg.pose.position.z
        quat = [nearest_odom_msg.pose.orientation.x, nearest_odom_msg.pose.orientation.y, nearest_odom_msg.pose.orientation.z, nearest_odom_msg.pose.orientation.w]
        roll, pitch, yaw = tf.transformations.euler_from_quaternion(quat)
        return (nearest_pose_x, nearest_pose_y, nearest_pose_z, roll, pitch, yaw)

    def update_Circlepose(self, circles_pose_x, circles_pose_y, circles_pose_z, circles_pose_yaw):    

        threshold = 3  # 单位：m
        circle_pose = Circle_pose()
        if len(Circle_pose_list) >= 16:  # 如果Circle_pose_list长度超过16，则删除最早的数据
            Circle_pose_list.pop(0)  # 删除最早的数据
        elif len(Circle_pose_list) == 0:
            circle_pose.x = circles_pose_x
            circle_pose.y = circles_pose_y
            circle_pose.z = circles_pose_z
            circle_pose.yaw = circles_pose_yaw
            #circle_pose = circle_pose.Transform()
            Circle_pose_list.append(circle_pose)  # 如果Circle_pose_list为空，直接添加数据
            return
        #Debug用    print(Circle_pose_list[1].x, Circle_pose_list[1].y, Circle_pose_list[1].z)

        #如果Circle_pose中每一个元素与传入的元素间的距离都大于阈值，则加入Circle_pose中
        
        if all(abs(math.sqrt(math.pow((x.x - circles_pose_x), 2) + math.pow((x.y - circles_pose_y), 2) + math.pow((x.z - circles_pose_z), 2))) > threshold for x in Circle_pose_list):
        #if all(abs(x.position.x - circles_pose_x) > threshold for x in Circle_pose_list) and all(abs(y.position.y - circles_pose_y) > threshold for y in Circle_pose_list) and all(abs(z.position.z - circles_pose_z) > threshold for z in Circle_pose_list) and all(abs(yaw.yaw - circles_pose_yaw) > threshold for yaw in Circle_pose_list):
            circle_pose.x = circles_pose_x
            circle_pose.y = circles_pose_y
            circle_pose.z = circles_pose_z
            circle_pose.yaw = circles_pose_yaw * 180/math.pi
            #circle_pose = circle_pose.TraCircle_pose_cbnsform()
            Circle_pose_list.append(circle_pose)
        #else:
            #如果Circle_pose中存在一个元素与传入的元素间的距离小于阈值，则更新该元素为新传入元素与该元素的平均值
            #for circle_pose_temp in Circle_pose_list:
                #if abs(math.sqrt(math.pow((circle_pose_temp.x - circles_pose_x), 2) + math.pow((circle_pose_temp.y - circles_pose_y), 2) + math.pow((circle_pose_temp.z - circles_pose_z), 2))) < threshold:#                if abs(circle_pose_temp.x - circles_pose_x) < threshold and abs(circle_pose_temp.y - circles_pose_y) < threshold and abs(circle_pose_temp.z - circles_pose_z) < threshold and abs(circle_pose_temp.yaw - circles_pose_yaw) < threshold:
                    #circle_pose_temp.x = (circle_pose_temp.x + circles_pose_x) / 2
                    #circle_pose_temp.y = (circle_pose_temp.y + circles_pose_y) / 2
                    #circle_pose_temp.z = (circle_pose_temp.z + circles_pose_z) / 2
                    #circle_pose_temp.yaw = (circle_pose_temp.yaw + circles_pose_yaw) / 2
                    
        return
    def Circle_pose_pub(self):
        if rospy.is_shutdown():
            CirclePoses_msg = Circle_pose()
            self.Circle_pub(CirclePoses_msg.Circle_pose_list_transform())

    
def main():
    yolo_module = YOLO_MODULE()  #使yolo_module()类实例化
    circle_pose = Circle_pose()
    rospy.Subscriber("airsim_node/drone_1/front_left/Scene", Image, yolo_module.right_front_view_cb)   #订阅airsim_node发布的图像消息
    rospy.Subscriber("airsim_node/drone_1/debug/pose_gt", PoseStamped, yolo_module.Pose_Stamped_cb)  #订阅airsim_node发布的pose消息
    rospy.Subscriber("/airsim_node/drone_1/circle_poses", Circle, circle_pose.Circle_pose_cb)  #订阅airsim_node发布的circle_poses消息dom消息
    
    
    rospy.spin()

if __name__ == "__main__":
    main()
