#!/usr/bin/env python3

import cv2
import rospy
import tf.transformations
from cv_bridge import CvBridge
import time
#公用消息
from geometry_msgs.msg import PoseStamped
from sensor_msgs.msg import Image
from std_msgs.msg import Empty,String
#自定义消息
from yolo_ros.msg import yolomsg
#airsim消息
from airsim_ros.msg import Circle, CirclePoses, VelCmd, PoseCmd

#数学类
import math
import numpy as np



body_frame = [260,-45,0,45]

"""
    这是一个自定义的pose
"""
class Pose:
    def __init__(self) :
        self.x = 0
        self.y = 0
        self.z = 0
        self.pitch = 0
        self.yaw = 0
        self.roll = 0
"""
    这是一个自定义类，用于对点的选择
"""
class POS_CHOOSE:
    def __init__(self):   #初始化函数
        self.init_ros()
        self.got_sim = False
        self.Yolo_idx = 0  #yolo 的索引
        self.yolo_msg_mid = (0,0) #yolo的msg

        self.yolo_len_x = 0
        self.yolo_len_y = 0

        self.Circle_msg = CirclePoses()
        self.Yolo_Circle_msg = CirclePoses()

        self.Circle_pose_list_sim = []
        self.Yolo_pose_list=[]
        self.target_pub = rospy.Publisher("target", PoseStamped, queue_size=10)     #发布目标点
        self.target = Pose()
        self.pose = Pose()
        self.state_list = ["无目标","使用airsim","yolo_圆前","yolo_环","yolo_圆后"]
        self.curr_state = "无目标"

        self.ref_yaw = 0

    """
        这个函数用于初始化ROS节点
    
    """
    def init_ros(self):
        rospy.init_node("yolo_ros_sub_and_pub")

    """
        这个函数用于订阅airsim_node发布的pose消息,是个实时位置的获得函数
    """
    def Pose_Stamped_cb(self, msg):
        self.pose.x = msg.pose.position.x
        self.pose.y = msg.pose.position.y
        self.pose.z = msg.pose.position.z
        quat = [msg.pose.orientation.x, msg.pose.orientation.y, msg.pose.orientation.z, msg.pose.orientation.w]
        roll, pitch, yaw = tf.transformations.euler_from_quaternion(quat)
        self.pose.roll = roll
        self.pose.pitch = pitch
        self.pose.yaw = yaw
    """
    
        这个函数用于订阅airsim_node发布的circle_poses消息,是个圆环点的获得函数
    
    """
    def Circle_pose_cb(self, Circle_msg):
        if not self.got_sim :#如果已经获得了airsim_node发布的circle_poses消息，那么就不再更新
            self.Circle_msg = Circle_msg
            self.got_sim = True
    """
        Yolo_CirclePose_cb yolo的回调函数
    """
    def Yolo_CirclePose_cb(self, msg):
        self.Yolo_Circle_msg = msg

    def yolo_msg_cb(self,msg):
        xmin,xmax,ymin,ymax = msg.xmin,msg.xmax,msg.ymin,msg.ymax 
        self.yolo_len_x = abs(msg.xmax-xmin)
        self.yolo_len_y = abs(msg.ymax-ymin)
        xmid = (xmin + xmax)/2
        ymid = (ymin + ymax)/2
        self.yolo_msg_mid=(xmid,ymid)



    def translation_matrix(self,tx, ty, tz):
        """
        生成平移矩阵。
        """
        return np.array([
            [1, 0, 0, tx],
            [0, 1, 0, ty],
            [0, 0, 1, tz],
            [0, 0, 0, 1]
        ])
    def rotation_matrix_from_body_to_world(self):
        """
        生成从机体坐标系到世界坐标系的旋转矩阵。
        """
        # 因为机体坐标系的Z轴指向上方，世界坐标系的Z轴指向下方
        # 需要180度绕X轴旋转
        angle = np.radians(180)
        Rx = np.array([
            [1, 0, 0],
            [0, np.cos(angle), -np.sin(angle)],
            [0, np.sin(angle), np.cos(angle)]
        ])

        return Rx
    def rotation_matrix(self, pitch, yaw, roll):
        """
        生成绕机体坐标系的旋转矩阵（前X轴，右Y轴，上Z轴）。
        """
        pitch, yaw, roll = np.radians([pitch, yaw, roll])
    
        # 绕机体X轴旋转
        Rx = np.array([
            [1, 0, 0],
            [0, np.cos(pitch), -np.sin(pitch)],
            [0, np.sin(pitch), np.cos(pitch)]
        ])
    
        # 绕机体Y轴旋转
        Ry = np.array([
            [np.cos(yaw), 0, np.sin(yaw)],
            [0, 1, 0],
            [-np.sin(yaw), 0, np.cos(yaw)]
        ])
    
        # 绕机体Z轴旋转
        Rz = np.array([
            [np.cos(roll), -np.sin(roll), 0],
            [np.sin(roll), np.cos(roll), 0],
            [0, 0, 1]
        ])
    
        # 组合旋转矩阵（先绕X轴旋转，再绕Y轴旋转，最后绕Z轴旋转）
        R = Rz @ Ry @ Rx
        return R

    def apply_transformation(self, x, y, z, tx, ty, tz, pitch, yaw, roll):        # 将点(x, y, z)从机体坐标系变换到世界坐标系
        """
        将机体坐标系下的点 (x, y, z) 转换到世界坐标系下。
        """
        # 生成从机体坐标系到世界坐标系的旋转矩阵
        R_body_to_world = self.rotation_matrix_from_body_to_world()
    
        # 生成机体坐标系下的旋转矩阵
        R_body = self.rotation_matrix(pitch, yaw, roll)
    
        # 组合旋转矩阵（先应用机体坐标系到世界坐标系的旋转，再应用机体坐标系的旋转）
        R_total = R_body_to_world @ R_body
    
        # 生成平移矩阵
        T = self.translation_matrix(tx, ty, tz)
    
        # 形成完整的变换矩阵（旋转 + 平移）
        transformation_matrix = np.vstack([np.hstack([R_total, np.array([[0], [0], [0]])]), [0, 0, 0, 1]])
    
        # 目标点坐标（加上齐次坐标）
        point = np.array([x, y, z, 1])
    
        # 应用变换
        transformed_point = transformation_matrix @ point
    
        return transformed_point[:3]

    
    """
        这里用来检查是否到达目标点
    """
    def reached_goal_position(self):
        # 假设目标点与当前位置的距离小于1m，认为已到达
        distance = np.sqrt((self.target.x - self.pose.x) ** 2 + (self.target.y - self.pose.y) ** 2 + (self.target.z - self.pose.z) ** 2)
        if distance < 2:
            return True
        else:
            return False
    """
        这里用于选择目标点
        这个函数用于选择距离当前位置最近的点作为目标点
        但是，这里需要判断一下，如果yolo检测到的点为空，那么就选择airsim_node发布的circle_poses消息中的点
        注意，yolo检测到的点为空，那么就选择airsim_node发布的circle_poses消息中的点
        有问题
    """
    def choose_target(self):
        target = PoseStamped()
        if self.curr_state == self.state_list[0]:
            #如果当前状态为无目标，那么下一个点就是airsim_node发布的circle_poses消息中的点，Circle_pose_list_sim
            print("是我在运行")
            self.target.x = self.Circle_msg.poses[0].position.x
            self.target.y = self.Circle_msg.poses[0].position.y
            self.target.z = self.Circle_msg.poses[0].position.z
            self.target.yaw = self.ref_yaw * math.pi/180
            #self.target.yaw = self.Circle_msg.poses[0].yaw
            if self.target.z > 0:
                self.target.z = -self.target.z

            #赋值给目标点
            print("在choose——target中，目标点的坐标为：",self.target.x,self.target.y,self.target.z,self.target.yaw)
            target.pose.position.x = self.target.x
            target.pose.position.y = self.target.y
            target.pose.position.z = self.target.z
            target.pose.orientation.x = 0
            self.target_pub.publish(target)
            self.curr_state = self.next_state()
            #更新状态
            print("出栈",self.Circle_msg.poses.pop(0))
            #删除已经到达的点
        elif self.curr_state == self.state_list[1]:
            #如果当前状态是“使用airsim”那么下一个就是yolo前的点
            print("分支一在运行")
            while (abs(self.yolo_msg_mid[0] - 320) > 160 or abs(self.yolo_msg_mid[1] -240) > 120): #如果yolo检测到的点不在屏幕中间
                if self.yolo_msg_mid[0]-320 > 0 :
                    Dx,Dy,Dz =self.apply_transformation(0, 0.1, 0, body_frame[0], body_frame[1], body_frame[2], self.pose.pitch, self.pose.yaw, self.pose.roll)
                    self.target.x = self.pose.x + Dx
                    self.target.y = self.pose.y + Dy
                    self.target.z = self.pose.z + Dz
                    if self.yolo_len_y>self.yolo_len_x:
                        self.target.yaw = (self.pose.yaw-0.1) * math.pi/180
                elif self.yolo_msg_mid[0]-320 < 0:
                    Dx,Dy,Dz =self.apply_transformation(0, -0.1, 0, body_frame[0], body_frame[1], body_frame[2], self.pose.pitch, self.pose.yaw, self.pose.roll)
                    self.target.x = self.pose.x + Dx
                    self.target.y = self.pose.y + Dy
                    self.target.z = self.pose.z + Dz
                    if self.yolo_len_y>self.yolo_len_x:
                        self.target.yaw = (self.pose.yaw+0.1) * math.pi/180
                if self.yolo_msg_mid[1]-240 > 0:
                    Dx,Dy,Dz =self.apply_transformation(0, 0, -0.1, body_frame[0], body_frame[1], body_frame[2], self.pose.pitch, self.pose.yaw, self.pose.roll)
                    self.target.x = self.pose.x + Dx
                    self.target.y = self.pose.y + Dy
                    self.target.z = self.pose.z + Dz
                    self.target.yaw = self.pose.yaw
                elif self.yolo_msg_mid[1]-240 < 0:
                    Dx,Dy,Dz =self.apply_transformation(0, 0, 0.1, body_frame[0], body_frame[1], body_frame[2], self.pose.pitch, self.pose.yaw, self.pose.roll)
                    self.target.x = self.pose.x + Dx
                    self.target.y = self.pose.y + Dy
                    self.target.z = self.pose.z + Dz
                    self.target.yaw = self.pose.yaw
                elif self.yolo_msg_mid == (0,0):#如果yolo检测不到点
                    self.target.x = self.pose.x
                    self.target.y = self.pose.y
                    self.target.z = self.pose.z
                    self.target.yaw = self.pose.yaw+1
                    print("在choose——target中，yolo检测不到点，目标点的坐标为：",self.target.x,self.target.y,self.target.z,self.target.yaw)

                target.pose.position.x = self.target.x
                target.pose.position.y = self.target.y
                target.pose.position.z = self.target.z
                target.pose.orientation.x = self.target.yaw
                
                self.target_pub.publish(target)
                print("正在调整位置，且已发布目标点")
            self.target.x = self.Yolo_Circle_msg.poses[self.Yolo_idx].position.x - 5 * np.cos(self.Yolo_Circle_msg.poses[self.Yolo_idx].yaw * math.pi/180)
            self.target.y = self.Yolo_Circle_msg.poses[self.Yolo_idx].position.y - 5* np.sin(self.Yolo_Circle_msg.poses[self.Yolo_idx].yaw * math.pi/180)
            self.target.z = self.Yolo_Circle_msg.poses[self.Yolo_idx].position.z
            self.target.yaw = self.Yolo_Circle_msg.poses[self.Yolo_idx].yaw

            self.ref_yaw = self.Yolo_Circle_msg.poses[self.Yolo_idx].yaw
            
            target.pose.position.x = self.target.x
            target.pose.position.y = self.target.y
            target.pose.position.z = self.target.z
            target.pose.orientation.x = self.target.yaw

            self.target_pub.publish(target)
            self.curr_state = self.next_state()
            print("调整位置完成，已发布目标点")
        elif self.curr_state == self.state_list[2] :
            #如果现在的状态是“yolo_圆前”那么下一个状态就是“yolo_圆“
            self.target.x = self.Yolo_Circle_msg.poses[self.Yolo_idx].position.x
            self.target.y = self.Yolo_Circle_msg.poses[self.Yolo_idx].position.y
            self.target.z = self.Yolo_Circle_msg.poses[self.Yolo_idx].position.z
            self.target.yaw = self.Yolo_Circle_msg.poses[self.Yolo_idx].yaw

            target.pose.position.x = self.target.x
            target.pose.position.y = self.target.y
            target.pose.position.z = self.target.z
            target.pose.orientation.x = self.target.yaw
            
            self.target_pub.publish(target)

            self.curr_state = self.next_state()
            print("分支2在运行")
        elif self.curr_state == self.state_list[3]:
            #如果现在的状态是“yolo_圆”那么下一个状态就是“yolo_圆后”
            self.target.x = self.Yolo_Circle_msg.poses[self.Yolo_idx].position.x + 5 * np.cos(self.Yolo_Circle_msg.poses[self.Yolo_idx].yaw * math.pi/180)
            self.target.y = self.Yolo_Circle_msg.poses[self.Yolo_idx].position.y + 5 * np.sin(self.Yolo_Circle_msg.poses[self.Yolo_idx].yaw * math.pi/180)
            self.target.z = self.Yolo_Circle_msg.poses[self.Yolo_idx].position.z
            self.target.yaw = self.Yolo_Circle_msg.poses[self.Yolo_idx].yaw

            target.pose.position.x = self.target.x
            target.pose.position.y = self.target.y
            target.pose.position.z = self.target.z
            target.pose.orientation.x = self.target.yaw

            self.target_pub.publish(target)

            #self.Yolo_idx += 1 #由于我们的yolo部分做了点修改，所以每次都是0，故而不需要加1了，为了保持代码的完整性，故而注释保留

            self.curr_state = self.next_state()
            print("分支3在运行")
        elif self.curr_state == self.state_list[4]:
            #如果现在的状态是“yolo_圆后”那么下一个状态就是“无目标”
            self.curr_state = self.next_state()
            print("递归")





    def next_state(self):
        if self.curr_state == self.state_list[0]:
            self.curr_state = self.state_list[1]
        elif self.curr_state == self.state_list[1]:
            self.curr_state = self.state_list[2]
        elif self.curr_state == self.state_list[2]:
            self.curr_state = self.state_list[3]
        elif self.curr_state == self.state_list[3]:
            self.curr_state = self.state_list[4]
        elif self.curr_state == self.state_list[4]:
            self.curr_state = self.state_list[0]
        else :
            print("Error: invalid state")
            self.curr_state = self.state_list[0]
        return self.curr_state
    
    def timer_cb(self,msg):
        pos=POS_CHOOSE()
        tar = PoseStamped()
        print("当前状态",self.curr_state)
        print("目标点",self.target.x, self.target.y, self.target.z, self.target.yaw)
        print("当前位置",self.pose.x, self.pose.y, self.pose.z, self.pose.yaw)
        #print("Cir——sim",self.Circle_pose_list_sim[15].x, self.Circle_pose_list_sim[0].y, self.Circle_pose_list_sim[0].z, self.Circle_pose_list_sim[0].yaw)
        tar.pose.position.x = self.target.x
        tar.pose.position.y = self.target.y
        tar.pose.position.z = self.target.z
        tar.pose.orientation.x = self.target.yaw
        if tar.pose.position.z >0 :
            tar.pose.position.z = -tar.pose.position.z
        
        self.target_pub.publish(tar)
        if self.reached_goal_position():
            self.choose_target()
            time.sleep(3)





def main():
    pose_choose = POS_CHOOSE()
    rospy.Subscriber("Circle_pose", CirclePoses, pose_choose.Yolo_CirclePose_cb)  #订阅发布的目标点PoseStamped消息,并发布到/target中,方便其他节点使用
    rospy.Subscriber("airsim_node/drone_1/debug/pose_gt", PoseStamped, pose_choose.Pose_Stamped_cb)  #订阅airsim_node发布的pose消息
    rospy.Subscriber("/airsim_node/drone_1/circle_poses", CirclePoses, pose_choose.Circle_pose_cb)  #订阅airsim_node发布的circle_poses消息dom消息
    rospy.Subscriber("yolomsg_right",yolomsg,pose_choose.yolo_msg_cb) #订阅yolomsg发布的消息
    timer = rospy.Timer(rospy.Duration(0.1), pose_choose.timer_cb) #设置定时器，每隔0.1秒调用一次timer_cb函数
    rospy.spin()

if __name__ == "__main__":
    main()