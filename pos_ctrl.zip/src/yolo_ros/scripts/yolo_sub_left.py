#!/usr/bin/env python3
import sys
sys.path.append('/home/misaka/auto_drone/src/yolo_ros/src/yolov10')
#修改工作区间，使其能够找到yolov10
from ultralytics import YOLOv10
import cv2
import rospy
import tf.transformations
from cv_bridge import CvBridge
#公用消息
from geometry_msgs.msg import PoseStamped
from sensor_msgs.msg import Image
from std_msgs.msg import Empty,String
#自定义消息
from yolo_ros.msg import  yolomsg
#airsim消息
from airsim_ros.msg import Circle, CirclePoses, VelCmd, PoseCmd
from airsim_ros.srv import Takeoff, Land, Reset, SetLocalPosition,SetLocalPositionRequest, TakeoffRequest

#数学类
import math
import numpy as np





odom_list = []
img_write_flag = False
yolo_new_flag = False
cls_name = ['Circle', 'Circle_NO16', 'Circle_Passed', 'Circle_Passing'] #定义检测类别
parameter = [1280, 400, 320, 240] 
# parameter [list] 第一个参数是圆内环的实际大小
# 第二个参数是摄像机的焦距
# 第三个参数是图像宽度/2
# 第四个参数是图像高度/2
# 注意：1200mm是不准的，因为yolo得到的是外径
# 所以需要根据实际情况进行修改

body_frame = [260,-45,0,45]
#摄像机在机体坐标系中的位置
#注意：这个位置是相对于机体坐标系而言的，单位是毫米
#定义：x，y，z；其中x轴指向前方，y轴指向右侧，z轴指向上方
#注意：这个位置是相对于机体坐标系而言的，单位是毫米

Circle_pose_list = []
#来自yolo的检测数据

Circle_pose_list_left = []
#来自yolo的检测数据 左相机

Circle_pose_list_right = []
#来自yolo的检测数据 右相机

Circle_pose_list_sim = []
#来自airsim的近似数据 来自/airsim_node/drone_1/circle_poses 话题
goal_path = []

target = PoseStamped()

def Circle_pose_list_Transport():
    circleposes = CirclePoses()
    circleposes.poses = []
    Circle_pose_list=got_average_pose_list()
    for i in range(len(Circle_pose_list)):
        circleposes.poses.append(Circle_pose_list[i].Transform())
        circleposes.poses[i].index = i
    #circleposes.poses = Circle_pose_list
    return circleposes



"""
    双目融合
"""
def got_circle_pose_list():
    circle=Circle_pose()

    for i in range(min(len(Circle_pose_list_left), len(Circle_pose_list_right))):
        circle.x = (Circle_pose_list_left[i].x + Circle_pose_list_right[i].x)/2
        circle.y = (Circle_pose_list_left[i].y + Circle_pose_list_right[i].y)/2
        circle.z = (Circle_pose_list_left[i].z + Circle_pose_list_right[i].z)/2
        circle.yaw = (Circle_pose_list_left[i].yaw + Circle_pose_list_right[i].yaw)/2

        Circle_pose_list.append(circle)
        """
    if len(Circle_pose_list) > 10000:
        Circle_pose_list.pop(0)
    target.pose.position.x = Circle_pose_list[0].x
    target.pose.position.y = Circle_pose_list[0].y
    target.pose.position.z = Circle_pose_list[0].z
    target.pose.orientation.x = Circle_pose_list[0].yaw        
        """





def got_average_pose_list():
    merged_lst = []
    circle = Circle_pose()
    for item in Circle_pose_list:
        merged = False
        for merged_item in merged_lst:
            if abs(merged_item.x - item.x) < 5 and abs(merged_item.y - item.y) < 5 and abs(merged_item.z - item.z) < 5 and abs(merged_item.yaw - item.yaw) < 30:
                merged_item.x = (merged_item.x + item.x) / 2
                merged_item.y = (merged_item.y + item.y) / 2
                merged_item.z = (merged_item.z + item.z) / 2
                merged_item.yaw = (merged_item.yaw + item.yaw) / 2
                merged = True
                break
        if not merged:
            merged_lst.append(item)
        if len(Circle_pose_list) > 1000:
            Circle_pose_list.pop(0)
            #Circle_pose_list
    return merged_lst

class Circle_pose :
    def __init__(self):
        self.x = 0
        self.y = 0
        self.z = 0
        self.yaw = 0
    def Transform(self):
        msg = Circle()
        msg.position.x = self.x
        msg.position.y = self.y
        msg.position.z = self.z
        msg.yaw = self.yaw
        return msg
    def Circle_pose_cb(self, Circle_msg):
        pose = Circle_pose()
        for i in range(len(Circle_msg.poses)):
            pose.x = Circle_msg.poses[i].position.x
            pose.y = Circle_msg.poses[i].position.y
            pose.z = Circle_msg.poses[i].position.z
            pose.yaw = Circle_msg.poses[i].yaw * math.pi/180
            Circle_pose_list_sim[i]=pose

class YOLO_MODULE:
    def __init__(self):   #初始化函数
        self.init_ros()
        self.cv_bridge = CvBridge()
        self.model = YOLOv10("src/yolo_ros/src/yolov10/runs/detect/train9/weights/best.pt")
        #self.model = YOLO("/home/misaka/ROS_catkin_Yolo-V10/src/yolo_ros/src/yolov10/runs/detect/train3/weights/best.pt")
        self.pub = rospy.Publisher("yolomsg_left", yolomsg, queue_size=10)       #这个默认是左边的
        self.pub_right = rospy.Publisher("yolomsg_right", yolomsg, queue_size=10)           #右边的
        self.Circle_pub = rospy.Publisher("Circle_pose", CirclePoses, queue_size=10)
        #self.next_goal_pub = rospy.Publisher("next_goal", Circle, queue_size=10)
        self.target_pub = rospy.Publisher("target", PoseStamped, queue_size=10)     #发布目标点
        self.time_threshold = 0.005
        self.curr_stamp = rospy.Time.now()
        self.past_stamp = rospy.Time.now()
        #当前点
        self.pose = Pose()
        self.pose.x = 0
        self.pose.y = 0
        self.pose.z = 0
        self.pose.yaw = 0
        #目标点
        self.goal = Pose()
        self.goal.x = 0
        self.goal.y = 0
        self.goal.z = 0
        self.goal.yaw = 0

        
    def init_ros(self):
        rospy.init_node("yolo_ros_pub")

    def yolo_timer_callback(self, msg):
        rospy.loginfo("获得时间")

        if len(goal_path) > 0 :
            self.goal.x = goal_path[0][0]
            self.goal.y = goal_path[0][1]
            self.goal.z = goal_path[0][2]
            self.goal.yaw = goal_path[0][3]
            #goal_path.pop(0)

            target.pose.position.x = self.goal.x
            target.pose.position.y = self.goal.y
            target.pose.position.z = self.goal.z
            target.pose.orientation.x = self.goal.yaw

            self.target_pub.publish(target)
            print("目标点：",target.pose.position.x,target.pose.position.y,target.pose.position.z,self.goal.yaw)
        else:
            self.goal = self.pose
            

    def got_goal_path(self):
        
        for i in range(len(Circle_pose_list_sim)):
            tube1 = (Circle_pose_list_sim[i].x,Circle_pose_list_sim[i].y,Circle_pose_list_sim[i].z,Circle_pose_list_sim[i].yaw)
            print(tube1,"我是tube1")
            goal_path.append(tube1)
            tube2 = (Circle_pose_list[i].x-math.cos(Circle_pose_list[i].yaw),Circle_pose_list[i].y-math.sin(Circle_pose_list[i].yaw),Circle_pose_list[i].z,Circle_pose_list[i].yaw)
            goal_path.append(tube2)
            tube3 = (Circle_pose_list[i].x,Circle_pose_list[i].y,Circle_pose_list[i].z,Circle_pose_list[i].yaw)
            goal_path.append(tube3)
            tube4 = (Circle_pose_list[i].x+math.cos(Circle_pose_list[i].yaw),Circle_pose_list[i].y+math.sin(Circle_pose_list[i].yaw),Circle_pose_list[i].z,Circle_pose_list[i].yaw)
            goal_path.append(tube4)


    """
        reached_goal_position()函数
        检查是否到达了目标点
    """
    def reached_goal_position(self):
        # 假设目标点与当前位置的距离小于1m，认为已到达
        distance = np.sqrt((self.goal.x - self.pose.x) ** 2 + (self.goal.y - self.pose.y) ** 2 + (self.goal.z - self.pose.z) ** 2)
        if distance < 1:
            return True
        else:
            return False





    def right_front_view_cb(self, msg):  #定义Image回调函数
        self.curr_stamp = rospy.Time.now()
        if (self.curr_stamp - self.past_stamp).to_sec() <= self.time_threshold: # 如果时间间隔小于阈值，则不处理
            return
        else:
            self.past_stamp = self.curr_stamp
            timestamp = msg.header.stamp
            yolomsgs = yolomsg()        # 创建yolomsg并填入数据
            yolomsgs.timestamp = timestamp
            cv_image = self.cv_bridge.imgmsg_to_cv2(msg, "bgr8")   #将ROS图像消息转换为OpenCV图像   
            results = self.model.predict(cv_image)   #使用 YOLOv10 执行对象检测 
            #发布yolomsg
            # 创建yolomsg并填入数据
            # 并发布yolomsg
            # 若需要将检测结果保存到本地，请将img_write_flag置为True，并在rosrun中加入参数：--img-write
            # 注意：需要保证所需路径存在，否则会报出 IOError 并跳过此次循环
            # 若不希望保存图片，请将 img_write_flag 置为 False
            
            for r in results:
                circles_id = 0 # 初始化一个变量来存储检测框的id
                for box in r.boxes: 
                    box_list = box.xyxy.tolist()
                    box_list = [x for x in box_list[0]]
                    xmin, ymin, xmax, ymax = box_list
                    yolomsgs.xmin, yolomsgs.ymin, yolomsgs.xmax, yolomsgs.ymax = box_list

                    yolomsgs.Confidence = r.boxes.conf.tolist()[circles_id] #将置信度转换为字符串
                    yolomsgs.class_str = str(cls_name[int(r.boxes.cls.tolist()[circles_id])]) #将类别转换为字符串
                    yolomsgs.id = circles_id
                    
                    if str(cls_name[int(r.boxes.cls.tolist()[circles_id])]) == "Circle" and r.boxes.conf.tolist()[circles_id] >= 0.6:
                        dis_to_front, dis_to_hight, dis_to_width = self.get_distance_to_image(xmin, ymin, xmax, ymax)
                        pose_x, pose_y, pose_z, roll, pitch, pose_yaw = self.Traverse_point(timestamp)
                        if abs(roll) <= 0.006 and abs(pitch) <= 0.006 :

                            x,y,z = self.apply_transformation(dis_to_front, dis_to_width, dis_to_hight, body_frame[0], body_frame[1], body_frame[2], pitch, pose_yaw, roll)
                            yaw =pose_yaw+math.atan((dis_to_width + body_frame[1])/(dis_to_front + body_frame[0]))
                            
                            yolomsgs.circles_pose_x = pose_x+x/1000
                            yolomsgs.circles_pose_y = pose_y-y/1000
                            yolomsgs.circles_pose_z = pose_z+z/1000
                            yolomsgs.circles_pose_yaw = yaw

                            circle_poses = Circle_pose()
                            circle_poses.x = pose_x+x/1000
                            circle_poses.y = pose_y-y/1000
                            circle_poses.z = pose_z+z/1000
                            circle_poses.yaw = yaw
                            Circle_pose_list_right.append(circle_poses)
                        else:
                            yolomsgs.circles_pose_x = 0
                            yolomsgs.circles_pose_y = 0
                            yolomsgs.circles_pose_z = 0
                            yolomsgs.circles_pose_yaw = 0

                        self.pub_right.publish(yolomsgs)                #发布yolomsg
                    circles_id+=1
            got_circle_pose_list()
            cv2.imshow("img",cv_image)
            cv2.waitKey(1)
            rospy.loginfo("本次右目推演用时： %s 秒", (rospy.Time.now() - self.curr_stamp).to_sec())


    def left_front_view_cb(self, msg):  #定义Image回调函数
        self.curr_stamp = rospy.Time.now()
        if (self.curr_stamp - self.past_stamp).to_sec() <= self.time_threshold: # 如果时间间隔小于阈值，则不处理
            return
        else:
            self.past_stamp = self.curr_stamp
            timestamp = msg.header.stamp
            yolomsgs = yolomsg()        # 创建yolomsg并填入数据
            yolomsgs.timestamp = timestamp
            cv_image = self.cv_bridge.imgmsg_to_cv2(msg, "bgr8")   #将ROS图像消息转换为OpenCV图像   
            results = self.model.predict(cv_image)   #使用 YOLOv10 执行对象检测 
            #发布yolomsg
            # 创建yolomsg并填入数据
            # 并发布yolomsg
            # 若需要将检测结果保存到本地，请将img_write_flag置为True，并在rosrun中加入参数：--img-write
            # 注意：需要保证所需路径存在，否则会报出 IOError 并跳过此次循环
            # 若不希望保存图片，请将 img_write_flag 置为 False
            
            for r in results:
                circles_id = 0 # 初始化一个变量来存储检测框的id
                for box in r.boxes: 
                    box_list = box.xyxy.tolist()
                    box_list = [x for x in box_list[0]]
                    xmin, ymin, xmax, ymax = box_list
                    yolomsgs.xmin, yolomsgs.ymin, yolomsgs.xmax, yolomsgs.ymax = box_list

                    yolomsgs.Confidence = r.boxes.conf.tolist()[circles_id] #将置信度转换为字符串
                    yolomsgs.class_str = str(cls_name[int(r.boxes.cls.tolist()[circles_id])]) #将类别转换为字符串
                    yolomsgs.id = circles_id
                    
                    if str(cls_name[int(r.boxes.cls.tolist()[circles_id])]) == "Circle" and r.boxes.conf.tolist()[circles_id] >= 0.6:
                        dis_to_front, dis_to_hight, dis_to_width = self.get_distance_to_image(xmin, ymin, xmax, ymax)
                        pose_x, pose_y, pose_z, roll, pitch, pose_yaw = self.Traverse_point(timestamp)

                        if abs(roll) <= 0.006 and abs(pitch) <= 0.006 :

                            x,y,z = self.apply_transformation(dis_to_front, dis_to_width, dis_to_hight, body_frame[0], body_frame[1], body_frame[2], pitch, pose_yaw, roll)
                            yaw =pose_yaw+math.atan((dis_to_width + body_frame[1])/(dis_to_front + body_frame[0]))
                            
                            yolomsgs.circles_pose_x = pose_x+x/1000
                            yolomsgs.circles_pose_y = pose_y-y/1000
                            yolomsgs.circles_pose_z = pose_z+z/1000
                            yolomsgs.circles_pose_yaw = yaw

                            circle_poses = Circle_pose()
                            circle_poses.x = pose_x+x/1000
                            circle_poses.y = pose_y-y/1000
                            circle_poses.z = pose_z+z/1000
                            circle_poses.yaw = yaw
                            Circle_pose_list_left.append(circle_poses)
                            if len(Circle_pose_list_left)>10000:
                                Circle_pose_list_left.pop(0)
                        else:
                            yolomsgs.circles_pose_x = 0
                            yolomsgs.circles_pose_y = 0
                            yolomsgs.circles_pose_z = 0
                            yolomsgs.circles_pose_yaw = 0

                        self.pub.publish(yolomsgs)                #发布yolomsg
                    circles_id+=1
            #self.Circle_pub.publish(Circle_pose_list_Transport())   #发布Circle_pose
            self.got_goal_path()
            print("设置goal成功")
            rospy.loginfo("本次左目推演用时： %s 秒", (rospy.Time.now() - self.curr_stamp).to_sec())


    #用于计算物体距离图像的距离，回出物体距离相机的距离，与距离换面中心的距离
    def get_distance_to_image(self, xmin, ymin, xmax, ymax):
        distance_object_to_image = (parameter[1] * parameter[0])/(math.sqrt((xmax - xmin) * (ymax - ymin)))
        y_to_hight = -(distance_object_to_image * (((ymax + ymin) / 2) - parameter[3])) / parameter[1]
        #这里有负号是因为图像坐标系和相机坐标系y轴方向相反
        x_to_width = (distance_object_to_image * (((xmax + xmin) / 2) - parameter[2])) / parameter[1]
        return (distance_object_to_image, y_to_hight, x_to_width)
    

    def translation_matrix(self,tx, ty, tz):
        """
        生成平移矩阵。
        """
        return np.array([
            [1, 0, 0, tx],
            [0, 1, 0, ty],
            [0, 0, 1, tz],
            [0, 0, 0, 1]
        ])
    def rotation_matrix_from_body_to_world(self):
        """
        生成从机体坐标系到世界坐标系的旋转矩阵。
        """
        # 因为机体坐标系的Z轴指向上方，世界坐标系的Z轴指向下方
        # 需要180度绕X轴旋转
        angle = np.radians(180)
        Rx = np.array([
            [1, 0, 0],
            [0, np.cos(angle), -np.sin(angle)],
            [0, np.sin(angle), np.cos(angle)]
        ])

        return Rx
    def rotation_matrix(self, pitch, yaw, roll):
        """
        生成绕机体坐标系的旋转矩阵（前X轴，右Y轴，上Z轴）。
        """
        pitch, yaw, roll = np.radians([pitch, yaw, roll])
    
        # 绕机体X轴旋转
        Rx = np.array([
            [1, 0, 0],
            [0, np.cos(pitch), -np.sin(pitch)],
            [0, np.sin(pitch), np.cos(pitch)]
        ])
    
        # 绕机体Y轴旋转
        Ry = np.array([
            [np.cos(yaw), 0, np.sin(yaw)],
            [0, 1, 0],
            [-np.sin(yaw), 0, np.cos(yaw)]
        ])
    
        # 绕机体Z轴旋转
        Rz = np.array([
            [np.cos(roll), -np.sin(roll), 0],
            [np.sin(roll), np.cos(roll), 0],
            [0, 0, 1]
        ])
    
        # 组合旋转矩阵（先绕X轴旋转，再绕Y轴旋转，最后绕Z轴旋转）
        R = Rz @ Ry @ Rx
        return R

    def apply_transformation(self, x, y, z, tx, ty, tz, pitch, yaw, roll):        # 将点(x, y, z)从机体坐标系变换到世界坐标系
        """
        将机体坐标系下的点 (x, y, z) 转换到世界坐标系下。
        """
        # 生成从机体坐标系到世界坐标系的旋转矩阵
        R_body_to_world = self.rotation_matrix_from_body_to_world()
    
        # 生成机体坐标系下的旋转矩阵
        R_body = self.rotation_matrix(pitch, yaw, roll)
    
        # 组合旋转矩阵（先应用机体坐标系到世界坐标系的旋转，再应用机体坐标系的旋转）
        R_total = R_body_to_world @ R_body
    
        # 生成平移矩阵
        T = self.translation_matrix(tx, ty, tz)
    
        # 形成完整的变换矩阵（旋转 + 平移）
        transformation_matrix = np.vstack([np.hstack([R_total, np.array([[0], [0], [0]])]), [0, 0, 0, 1]])
    
        # 目标点坐标（加上齐次坐标）
        point = np.array([x, y, z, 1])
    
        # 应用变换
        transformed_point = transformation_matrix @ point
    
        return transformed_point[:3]
    
    def Pose_Stamped_cb(self, msg):
        self.pose.x = msg.pose.position.x
        self.pose.y = msg.pose.position.y
        self.pose.z = msg.pose.position.z
        quat = [msg.pose.orientation.x, msg.pose.orientation.y, msg.pose.orientation.z, msg.pose.orientation.w]
        roll, pitch, yaw = tf.transformations.euler_from_quaternion(quat)
        self.pose.yaw = yaw
    #Pose_Stamped_cb函数
    #作用：订阅odom话题，获取当前位置信息
    #最大长度：1000
    def Pose_Stamped_cb(self, odom_msg):
        self.pose.x = odom_msg.pose.position.x
        self.pose.y = odom_msg.pose.position.y
        self.pose.z = odom_msg.pose.position.z
        quat = [odom_msg.pose.orientation.x, odom_msg.pose.orientation.y, odom_msg.pose.orientation.z, odom_msg.pose.orientation.w]
        roll, pitch, yaw = tf.transformations.euler_from_quaternion(quat)
        self.pose.yaw = yaw

        self.curr_stamp = rospy.Time.now()
        if (self.curr_stamp - self.past_stamp).to_sec() <= self.time_threshold: # 如果时间间隔小于阈值，则不处理
            return
        else:
            odom_list.append(odom_msg)  #将时间戳和位置添加到odom_list中
            if len(odom_list) >= 5000:
                odom_list.pop(0)  #如果odom_list长度超过100，则删除最早的数据

    #遍历odom_list，找到与传入的时间戳最接近的数据
    def Traverse_point(self, timestamp):# 遍历odom_list，找到与传入的时间戳最接近的数据
        # 若odom_list为空，返回None             #因为更新足够快，所以其实不需要这个判断...
        #if len(odom_list) == 0:              #为了提升速度，把这个删了，如果需要的话可以加回来
        #    return None
        # 找到与传入的时间戳最接近的数据
        nearest_odom_msg = min(odom_list, key=lambda x: abs(x.header.stamp - timestamp))
        nearest_pose_x = nearest_odom_msg.pose.position.x
        nearest_pose_y = nearest_odom_msg.pose.position.y
        nearest_pose_z = nearest_odom_msg.pose.position.z
        quat = [nearest_odom_msg.pose.orientation.x, nearest_odom_msg.pose.orientation.y, nearest_odom_msg.pose.orientation.z, nearest_odom_msg.pose.orientation.w]
        roll, pitch, yaw = tf.transformations.euler_from_quaternion(quat)
        return (nearest_pose_x, nearest_pose_y, nearest_pose_z, roll, pitch, yaw)

class Pose:
    def __init__(self) :
        self.x = 0
        self.y = 0
        self.z = 0
        self.yaw = 0

class PIDParams:
    def __init__(self):
        #PID参数：P
        self.kp_x=1.5
        self.kp_y=1.5
        self.kp_z=1.5
        self.kp_yaw=2
        #D
        self.kd_x=0.5
        self.kd_y=0.5
        self.kd_z=0.5
        self.kd_yaw=0.5
        #I
        self.ki_x=0.018
        self.ki_y=0.018
        self.ki_z=0.018
        self.ki_yaw=0
        #到达阈值
        self.reached_thresh_xyz=0.6
        self.reached_yaw_degrees=4.0
        #最大速度
        self.max_vel_horz_abs = 1.5
        self.max_vel_vert_abs = 3
        self.max_yaw_rate_degree = 0.1
        #pose  
        self.integral = Pose()
        self.prev_error = Pose()
        self.curr_error = Pose()
        #inte
        self.i_term_x = 0
        self.i_term_y = 0
        self.i_term_z = 0
        self.i_term_yaw = 0
        #更新频率
        self.update_control_every_n_sec = 0.005

class Pose_ctrl:
    def __init__(self):
        #curr_pose现在的位置
        self.pose = Pose()
        self.pose.x = 0
        self.pose.y = 0
        self.pose.z = 0
        self.pose.yaw = 0
        self.takeoff_flag = False
        #目标点
        self.goal = Pose()
        self.goal.x = 0
        self.goal.y = 0
        self.goal.z = 0
        self.goal.yaw = 0
        #时间阈值
        self.time_threshold = 0.1  # 时间阈值，单位为秒
        #初始化ros节点
        #self.init_ros()
        #创建服务
        self.takeoff_client = rospy.ServiceProxy('/airsim_node/drone_1/takeoff', Takeoff)
        self.land_client = rospy.ServiceProxy('/airsim_node/drone_1/land', Land)
        self.reset_client = rospy.ServiceProxy('/airsim_node/reset', Reset)
        #发布目标点
        #self.set_goal_position = rospy.ServiceProxy('/airsim_node/local_position_goal/override', SetLocalPosition)
        #创建发布者
        #通过这两 个publisher实现对无人机的速度控制和姿态控制
        self.vel_publisher = rospy.Publisher('airsim_node/drone_1/vel_cmd_body_frame', VelCmd, queue_size=1)
        self.pose_publisher = rospy.Publisher('airsim_node/drone_1/pose_cmd_body_frame', PoseCmd, queue_size=1)
        #初始化SetLocalPositionRequest消息类型
        self.goal_position = SetLocalPositionRequest()
        #初始化Velcmd
        self.vel_cmd = VelCmd()
        #PIDparameters
        self.PID_Params = PIDParams()
        self.timer = rospy.Timer(rospy.Duration(0.5), self.timer_callback)

    def init_ros(self):
        rospy.init_node("Pose_ctrl")

    """
        set_goal_position_requist(self, x, y, z)函数
        说明：用于控制无人机的飞行姿态和速度。
        使用方法：调用set_goal_position_requist函数，传入目标点的x、y、z坐标，即可控制无人机飞到该位置。
    """

    def set_goal_position_requist(self, x, y, z, yaw):
        self.goal.x = x
        self.goal.y = y
        self.goal.z = z
        self.goal.yaw = yaw

    #def set_goal_position_requist(self, x, y, z, yaw):

        #self.goal.x = x
        #self.goal.y = y
        #self.goal.z = z
        #self.goal.yaw = yaw

        #self.goal_position.vehicle_name = 'drone_1'
        #self.goal_position.x = x
        #self.goal_position.y = y
        #self.goal_position.z = z
        #self.goal_position.yaw = yaw
        #self.set_goal_position.call(self.goal_position)
    
    """
        Takeoff函数
    """
    def takeoff_requist(self):
        if self.takeoff_flag == False:
            takeoff_req = TakeoffRequest()
            takeoff_req.waitOnLastTask = False
            self.takeoff_client.call(takeoff_req)
            self.takeoff_flag = True

    """
        Land函数
    """
    def Land(self):
        if self.takeoff_flag == True:
            land = Land()
            self.land_client.call(land)
            self.takeoff_flag = False
        
    """
        reached_goal_position()函数
        检查是否到达了目标点
    """
    def reached_goal_position(self):
        # 假设目标点与当前位置的距离小于1m，认为已到达
        distance = np.sqrt((self.goal.x - self.pose.x) ** 2 + (self.goal.y - self.pose.y) ** 2 + (self.goal.z - self.pose.z) ** 2)
        if distance < 1:
            return True
        else:
            return False

    """
        函数名:timer_callback(self, event)
        参数:event
        功能:定时器回调函数
        说明:这个函数是用来定时调用的回调函数,每0.5秒调用一次,可用于更新位置信息。
    """
    def timer_callback(self,event):
        if not self.takeoff_flag:
            self.takeoff_requist()
        self.set_goal(20,14,-1,0)
        rospy.loginfo("小飞棍来喽")
        
        if self.reached_goal_position():
            rospy.loginfo("到达目标点")

        rospy.loginfo("此程序运行正常")
        return event



    """
        函数名:Pose_Stamped_cb(self, msg)
        参数:self,msg
        功能:获得当时的位置
        说明:这个函数是用来订阅无人机当前位置的回调函数,当无人机位置发生变化时,会调用这个函数,并将当前位置的信息存储在self.pose中。
    """
    def Pose_Stamped_cb(self, msg):
        self.pose.x = msg.pose.position.x
        self.pose.y = msg.pose.position.y
        self.pose.z = msg.pose.position.z
        quat = [msg.pose.orientation.x, msg.pose.orientation.y, msg.pose.orientation.z, msg.pose.orientation.w]
        roll, pitch, yaw = tf.transformations.euler_from_quaternion(quat)
        self.pose.yaw = yaw

    """
        函数名:ensure_velcmd(self)
        参数:self
        功能:确保速度命令在安全范围内
        说明:这个函数是用来确保速度命令在安全范围内,如果速度命令超出了安全范围,就会将其限制在安全范围内。
    """ 

    def ensure_velcmd(self):
        if math.sqrt(math.pow(self.vel_cmd.twist.linear.x, 2)+math.pow(self.vel_cmd.twist.linear.y, 2)) > self.PID_Params.max_vel_horz_abs :
            self.vel_cmd.twist.linear.x = int(self.vel_cmd.twist.linear.x / math.sqrt(math.pow(self.vel_cmd.twist.linear.x, 2)+math.pow(self.vel_cmd.twist.linear.y, 2))) * self.PID_Params.max_vel_horz_abs
            self.vel_cmd.twist.linear.y = int(self.vel_cmd.twist.linear.y / math.sqrt(math.pow(self.vel_cmd.twist.linear.x, 2)+math.pow(self.vel_cmd.twist.linear.y, 2))) * self.PID_Params.max_vel_horz_abs
        
        if abs(self.vel_cmd.twist.linear.z) > self.PID_Params.max_vel_horz_abs :
            self.vel_cmd.twist.linear.z = int(self.vel_cmd.twist.linear.z / self.PID_Params.max_vel_vert_abs) * self.PID_Params.max_vel_vert_abs
        
        if abs(self.vel_cmd.twist.angular.z) > self.PID_Params.max_yaw_rate_degree :
            self.vel_cmd.twist.angular.z = int(self.vel_cmd.twist.angular.z / self.PID_Params.max_yaw_rate_degree) * self.PID_Params.max_yaw_rate_degree

    """
        函数名:pose_to_velcmd_PID_controller(self, x, y, z, yaw)
        参数:self,x, y, z, yaw
        功能:实现PID算法来控制无人机的速度
        说明:velcmd为速度指令,Velcmd()
    """
    def pose_to_velcmd_PID_controller(self):

        self.PID_Params.curr_error.x = self.goal.x - self.pose.x
        self.PID_Params.curr_error.y = self.goal.y - self.pose.y
        self.PID_Params.curr_error.z = self.goal.z - self.pose.z
        self.PID_Params.curr_error.yaw = self.angular_dist(self.pose.yaw, self.goal.yaw)

        p_term_x = self.PID_Params.kp_x * self.PID_Params.curr_error.x
        p_term_y = self.PID_Params.kp_y * self.PID_Params.curr_error.y
        p_term_z = self.PID_Params.kp_z * self.PID_Params.curr_error.z
        p_term_yaw = self.PID_Params.kp_yaw * self.PID_Params.curr_error.yaw

        d_term_x = self.PID_Params.kd_x * (self.PID_Params.curr_error.x - self.PID_Params.prev_error.x) / self.PID_Params.update_control_every_n_sec
        d_term_y = self.PID_Params.kd_y * (self.PID_Params.curr_error.y - self.PID_Params.prev_error.y) / self.PID_Params.update_control_every_n_sec
        d_term_z = self.PID_Params.kd_z * (self.PID_Params.curr_error.z - self.PID_Params.prev_error.z) / self.PID_Params.update_control_every_n_sec
        d_term_yaw = self.PID_Params.kp_yaw * (self.PID_Params.curr_error.yaw - self.PID_Params.prev_error.yaw) / self.PID_Params.update_control_every_n_sec

        self.PID_Params.prev_error = self.PID_Params.curr_error

        self.PID_Params.integral.x = self.PID_Params.integral.x + self.PID_Params.curr_error.x * self.PID_Params.update_control_every_n_sec 
        self.PID_Params.integral.y = self.PID_Params.integral.y + self.PID_Params.curr_error.y * self.PID_Params.update_control_every_n_sec  
        self.PID_Params.integral.z = self.PID_Params.integral.z + self.PID_Params.curr_error.z * self.PID_Params.update_control_every_n_sec 
        self.PID_Params.integral.yaw = self.PID_Params.integral.yaw + self.PID_Params.curr_error.yaw * self.PID_Params.update_control_every_n_sec

        i_term_x = self.PID_Params.ki_x * self.PID_Params.integral.x 
        i_term_y = self.PID_Params.ki_y * self.PID_Params.integral.y
        i_term_z = self.PID_Params.ki_z * self.PID_Params.integral.z
        i_term_yaw = self.PID_Params.ki_yaw * self.PID_Params.integral.yaw

        vx = p_term_x + d_term_x + i_term_x
        vy = p_term_y + d_term_y + i_term_y
        vz = p_term_z + d_term_z + i_term_z
        vyaw = p_term_yaw + d_term_yaw + i_term_yaw

        yaw = self.pose.yaw + self.PID_Params.update_control_every_n_sec/2*vyaw

        self.vel_cmd.twist.linear.x = math.cos(yaw)*vx+math.sin(yaw)*vy
        self.vel_cmd.twist.linear.y = -math.sin(yaw)*vx+math.cos(yaw)*vy
        self.vel_cmd.twist.linear.z = vz
        self.vel_cmd.twist.angular.z = vyaw

        #self.ensure_velcmd()  # 保证速度命令在安全范围内
        #self.pub_vel_cmd()  # 发布速度指令

    """
        函数名:angular_dist(self,curr_yaw, target_yaw)
        参数:self,curr_yaw, target_yaw
        功能:计算当前航向和目标航向之间的角度差
        说明:返回值是弧度，这是一个附属函数
    """
    def angular_dist(self, curr_yaw, target_yaw):
        curr_yaw_rad = math.radians(curr_yaw)
        target_yaw_rad = math.radians(target_yaw)
        return math.acos(math.cos(curr_yaw_rad) * math.cos(target_yaw_rad) + math.sin(curr_yaw_rad) * math.sin(target_yaw_rad))

    """
        函数名:pub_vel_cmd(self,velcmd)
        参数:self,velcmd
        功能:发布速度指令,并实现PID算法来控制无人机的速度
        说明:velcmd为速度指令,Velcmd()
    """
    def pub_vel_cmd(self):
        self.vel_publisher.publish(self.vel_cmd)
    """
        函数名:set_goal(self,x,y,z,yaw)
        参数:self,x,y,z,yaw
        功能:设置无人机的目标位置和航向
        说明:调用set_goal_position_requist()函数和pose_to_velcmd_PID_controller()函数来设置目标位置和速度指令
    """
    def set_goal(self,x,y,z,yaw):
        rospy.loginfo("获得目标: x={}, y={}, z={}, yaw={}".format(x, y, z, yaw))
        self.set_goal_position_requist(x,y,z,yaw)
        self.pose_to_velcmd_PID_controller()
        #self.ensure_velcmd()
        #self.pub_vel_cmd()

def main():
    yolo_module = YOLO_MODULE()  #使yolo_module()类实例化
    circle_pose = Circle_pose()
    #pose_ctrl = Pose_ctrl()
    #pose_ctrl.timer
    timer=rospy.Timer(rospy.Duration(0.03), yolo_module.yolo_timer_callback)  #创建一个定时器，每隔0.01秒调用一次my_callback函数
    rospy.Subscriber("airsim_node/drone_1/front_left/Scene", Image, yolo_module.left_front_view_cb)   #订阅airsim_node发布的图像消息
    rospy.Subscriber("airsim_node/drone_1/front_right/Scene", Image, yolo_module.right_front_view_cb)   #订阅airsim_node发布的图像消息

    #rospy.Subscriber("airsim_node/drone_1/debug/pose_gt", PoseStamped, pose_ctrl.Pose_Stamped_cb)  #订阅airsim_node发布的pose消息
    rospy.Subscriber("airsim_node/drone_1/debug/pose_gt", PoseStamped, yolo_module.Pose_Stamped_cb)  #订阅airsim_node发布的pose消息
    rospy.Subscriber("/airsim_node/drone_1/circle_poses", Circle, circle_pose.Circle_pose_cb)  #订阅airsim_node发布的circle_poses消息dom消息
    
    rospy.spin()

if __name__ == "__main__":
    main()