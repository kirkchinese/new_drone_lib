#include "ros/ros.h"
#include "/home/misaka/ROS_catkin_Yolo-V10/devel/include/yolo_ros/yolomsg.h"

 
void doyolomsg(const communication_yolo::yolomsg::ConstPtr& yolomsg)
{
    ROS_INFO("目标的坐标信息为：xmin=%d,ymin=%d,xmax=%d,ymax=%d",yolomsg->xmin,yolomsg->ymin,yolomsg->xmax,yolomsg->ymax); 
}
 
 int main(int argc, char *argv[])
 {
    setlocale(LC_ALL,"");
    ros::init(argc,argv,"yolo_ros_sub");
    ros::NodeHandle nh;
    ros::Subscriber sub =nh.subscribe("yolomsg",10,doyolomsg);
    ros::spin();
 }